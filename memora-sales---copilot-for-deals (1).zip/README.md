# Memora Sales — Deal Memory OS for Sales Teams

> **Tagline:** “Most agents just remember. Memora Sales learns from deal memory and turns it into the next best action.”

---

## 1. Product Overview

**Memora Sales** is a persistent Deal Memory Operating System designed for enterprise sales teams. In modern enterprise workflows (Dynamics 365 Sales, Microsoft Teams, Salesforce, Slack), sales platforms store static records—fields, status tags, and disconnected activity logs. When account executives prepare for calls, they are forced to either re-read fragmented threads or rely on generic CRM AI assistants that generate superficial, hallucinated summaries.

Memora Sales adds persistent per-deal memory on top of enterprise sales workflows. It captures interactions, recalls relevant history, reflects on pattern shifts and timeline risks, and delivers explainable next best actions backed by verifiable deal citations.

---

## 2. Core Thesis

**“Most agents just remember. Memora Sales learns from deal memory and turns it into the next best action.”**

Memora Sales does not just append notes. When a new customer signal is captured:
1. It retains the context in isolated per-deal memory.
2. It detects conflicts and interdependencies across deal stakeholders.
3. It updates the explicit Health Score formula with clear provenance.
4. It rewrites the With-Memory Call Brief so that the next conversation directly addresses the new context.
5. Every single recommendation is grounded in verifiable Timeline events via interactive citation chips.

---

## 3. Architecture & Positioning

```
┌────────────────────────────────────────────────────────┐
│            Existing Enterprise Workflows               │
│  (Dynamics 365 Sales · Salesforce · Teams · Slack)     │
└──────────────────────────┬─────────────────────────────┘
                           │ Interaction Events & Signals
                           ▼
┌────────────────────────────────────────────────────────┐
│             MEMORA SALES (DEAL MEMORY OS)              │
│                                                        │
│  1. CAPTURE   ──► Ingest live customer signals & notes │
│  2. RECALL    ──► Isolated per-deal memory retrieval   │
│  3. REFLECT   ──► Stakeholder & timeline conflict check│
│  4. ACT       ──► Grounded brief & What-If simulation  │
└──────────────────────────┬─────────────────────────────┘
                           │
       ┌───────────────────┴───────────────────┐
       ▼                                       ▼
┌──────────────┐                       ┌──────────────┐
│  Hindsight   │ (Graceful Fallback)   │ Deterministic│
│  / Groq Live │──────────────────────►│ Local Engine │
│  Provider    │                       │ (Guaranteed) │
└──────────────┘                       └──────────────┘
```

**Positioning Statement:**
Memora Sales does not replace existing CRM systems or pretend to be an entire CRM suite. It operates as the persistent deal memory layer. CRM records store *what happened*; Memora Sales remembers *why it matters and what to do next*.

---

## 4. Technology Stack (Non-Negotiable)

- **Backend:** Python 3, Flask, Jinja2 template engine
- **Frontend:** Vanilla JavaScript, Tailwind CSS (via CDN)
- **State Management:** In-memory per-deal isolation (no external database required, survives session refresh)
- **Deployment:** Port 3000, compatible with local CLI or standard cloud containers
- **Start Command:** `python app.py`

---

## 5. The Memory Design: Three Memory Categories

Memora organizes deal context into three explicit structures:

1. **EPISODES:**
   - Specific interactions, calls, emails, and meetings.
   - Example: *Executive Business Review with CIO Marcus Vance (Sept 18)*
2. **FACTS:**
   - Verified, stable deal parameters extracted across conversations.
   - Example: *Budget: $240K ARR · Procurement Window: 21 business days · Target Close: Nov 15*
3. **PLAYBOOKS:**
   - Reusable sales guidance matched to deal triggers.
   - Example: *Enterprise Security Fast-Track · Pilot-to-Procurement Conversion*

---

## 6. The Core Product Loop

```
  ┌──────────────┐
  │   CAPTURE    │ Rep records a signal (e.g., 2-week pilot request).
  └──────┬───────┘
         │
         ▼
  ┌──────────────┐
  │    RECALL    │ Memora retrieves isolated deal memory and facts.
  └──────┬───────┘
         │
         ▼
  ┌──────────────┐
  │   REFLECT    │ Identifies risk: 14-day pilot + 21-day legal window
  └──────┬───────┘ crosses Nov 15 fiscal close date.
         │
         ▼
  ┌──────────────┐
  │     ACT      │ Produces grounded brief: Agree to pilot, but trigger
  └──────────────┘ procurement review on Day 10 in parallel.
```

---

## 7. Health Score — Explicit Deterministic Formula

The Health Score does not use arbitrary or unexplained numbers. It exposes its exact mathematical formula in the UI:

$$\text{Health Score} = \text{Base Score (60)} + \sum(\text{Positive Evidence}) - \sum(\text{Risk Evidence})$$

### Baseline Breakdown (Acme Industries Expansion)
- **Base Score:** `60`
- **Positive Contributors:**
  - `+12`: Recent executive engagement (CIO Marcus Vance confirmed Q4 transformation priority)
  - `+10`: Champion technical endorsement (VP Architecture Elena Rostova signed off on deployment)
  - `+8`: Budget band verified ($200K–$260K allocated in confirmed FY Q4 budget)
  - `+6`: Defined evaluation milestones (Architecture review completed on schedule)
- **Negative Deductions (Risk Evidence):**
  - `-8`: Security & compliance review pending (Custom 84-question infosec review open)
  - `-6`: Procurement review window unstarted (21-day review buffer uninitiated)
  - `-4`: User-tier expansion pricing objection (Procurement queried seat 300-450 discount)
- **Initial Total:** $60 + 12 + 10 + 8 + 6 - 8 - 6 - 4 = \mathbf{78 / 100}$

When a rep captures: *“Customer wants a 2-week pilot before procurement review.”*, the system de-risks evaluation criteria, adding `+4` points (*Pilot scope clarified*), dynamically adjusting the score to **82 / 100**.

---

## 8. What-If Reasoning Engine

Memora provides three fixed strategic scenarios. Every simulation produces four structured dimensions grounded in deal memory:

1. **Offer 10% discount**
   - *Likely Reaction:* Procurement accepts concession, but VP Architecture Elena Rostova views it as avoiding open technical questions.
   - *Risk:* Weakens pricing power and burns $24,000 margin without shortening the 21-day legal window.
   - *Recommended Move:* Hold discount in reserve as a closing trade tied to an expedited 14-day procurement sign-off.
   - *Evidence:* Commercial sync (Sept 24), Procurement Window Fact, Commercial Concession Defense Playbook.

2. **Push for pilot first**
   - *Likely Reaction:* High champion alignment. Strongly matches Elena Rostova’s technical validation request.
   - *Risk:* 14-day pilot without parallel legal review pushes closing past November 15 fiscal deadline.
   - *Recommended Move:* Agree immediately to 2-week pilot, with Day 10 automatic trigger for legal review.
   - *Evidence:* Customer Pilot Request signal, Architecture Review (Sept 21), Nov 15 Close Date Fact.

3. **Lead with ROI story**
   - *Likely Reaction:* CIO Marcus Vance welcomes strategic business case for budget committee.
   - *Risk:* Fails to address the 8 pending infosec questions.
   - *Recommended Move:* Arm Marcus Vance with 1-page ROI brief while delivering Infosec bridge letter.
   - *Evidence:* Executive Review (Sept 18), Decision Maker Fact, Security Questionnaire (Sept 25).

---

## 9. Hindsight / Groq Integration & Fallback Safety

Memora Sales strictly follows a three-tier reliability hierarchy:

1. **Live Provider:** If `HINDSIGHT_API_KEY` or `GROQ_API_KEY` is configured and passes validation, live synthesis is utilized.
2. **Graceful Fallback:** If an external network call fails or times out, the deterministic engine takes over instantly.
3. **Deterministic Engine:** If no keys are provided, Memora operates 100% locally with zero external dependencies.

**Status Badge:**
- `Hindsight: live` (only when verified provider is active)
- `Hindsight: demo mode` (simulated live demo mode)
- `Hindsight: fallback` (provider failed, fallback active)
- `Hindsight: not configured` (honest, transparent state)

---

## 10. Demo Script (2–3 Minutes)

Follow this presenter script for evaluations or live demonstrations:

- **Step 1: Landing Page (First 10s)**
  - Open `http://localhost:3000/`.
  - State the thesis: *“Most agents just remember. Memora Sales learns from deal memory and turns it into the next best action.”*
  - Point to the memory loop: **Capture → Recall → Reflect → Act**.
  - Click **“Open Deal Workspace”**.

- **Step 2: Inspect Deal Identity & Health Score**
  - Point out **Acme Industries — Enterprise Expansion ($240K)**.
  - Notice Health Score: **78 / 100**.
  - Click **“Why this score?”** to reveal the explicit formula (+12 executive, -8 security delay, etc.).

- **Step 3: Test Citations in the Call Brief**
  - In the AI Call Brief, click the citation chip **`[Security objection]`**.
  - Observe how the screen smoothly scrolls to and pulses the **Infosec Questionnaire Submission** event.

- **Step 4: The Key Interactive Moment (Live Note Capture)**
  - Click **“⚡ Insert demo signal”** (or type):  
    *“Customer wants a 2-week pilot before procurement review.”*
  - Click **“Capture Memory”**.
  - Immediate confirmation appears:  
    *“Memory retained. The next brief now uses this context.”*

- **Step 5: Verify the Updated With-Memory Brief**
  - Observe how the With-Memory Call Brief automatically updates to recommend leading with the 2-week pilot.
  - Observe Health Score update from 78 to 82.
  - Click the new **`[2-week pilot request]`** citation to see the new live event highlighted.

- **Step 6: Toggle Without Memory vs. With Memory**
  - Click **WITHOUT MEMORY**: Show the generic CRM summary (*“Schedule follow-up call...”*).
  - Click **WITH MEMORY**: Show the grounded, actionable move (*“Lead with 2-week pilot framework...”*).

- **Step 7: Run What-If Scenario**
  - Click **“Push for pilot first”** in the What-If panel.
  - Show the 4 dimensions: *Likely Reaction*, *Risk*, *Recommended Move*, and *Grounded Evidence*.

---

## 11. Running the Application

### Prerequisites
- Python 3.10+
- Flask (`pip install flask requests`)

### Quick Start
```bash
python app.py
```
Open your browser to:
```
http://localhost:3000/
```

### Optional Environment Variables
```bash
export PORT=3000
export HINDSIGHT_API_KEY=""      # Optional
export GROQ_API_KEY=""           # Optional
export MEMORA_DEMO_MODE="false"  # Optional
```
If no environment variables are set, Memora Sales launches cleanly in deterministic engine mode.

---

## 12. Known Limitations & Scope Boundaries

- **Database:** By design, the demo operates with session-isolated in-memory state. No external database is required.
- **Enterprise Integrations:** Designed as the architectural memory layer for Dynamics 365, Teams, and Salesforce; the demo runs standalone without requiring active CRM tenant credentials.
- **Privacy:** Data isolation is maintained per deal ID.
