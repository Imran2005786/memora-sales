"""
deal_data.py - Data layer, state management, and deterministic reasoning engine
for Memora Sales (Copilot for Deals).

Preserves persistent per-deal memory isolation without requiring an external database.
Calculates explicit, evidence-backed Health Scores and powers the Capture -> Recall -> Reflect -> Act loop.
"""

from datetime import datetime
from copy import deepcopy
import hindsight_groq_service

# Initial pristine state of demo deals
INITIAL_DEALS = {
    "acme-expansion": {
        "id": "acme-expansion",
        "account": "Acme Industries",
        "name": "Enterprise Expansion",
        "stage": "Negotiation",
        "value": "$240K",
        "value_num": 240000,
        "target_close": "Nov 15 (FY Q4)",
        "last_activity": "Technical Architecture Review completed · 2h ago",
        "owner": "Sarah Chen",
        "sponsor": "Marcus Vance (CIO)",
        "champion": "Elena Rostova (VP Architecture)",
        "procurement": "David Zhang (Lead Procurement)",
        "memory_status": "MEMORY-GROUNDED",
        "memory_state_label": "Persistent isolation active",
        "summary": "Expanding platform deployment to 450 enterprise engineering and ops seats across 4 business units.",
        
        # Explicit Health Score Configuration
        # Base: 60. Final initial score = 78 / 100
        "base_health": 60,
        "health_contributors": [
            {
                "id": "c-exec",
                "label": "Recent executive engagement",
                "evidence": "CIO Marcus Vance confirmed Q4 transformation priority in business review",
                "points": 12,
                "type": "positive",
                "source_event": "evt-01"
            },
            {
                "id": "c-champ",
                "label": "Champion technical endorsement",
                "evidence": "VP Architecture Elena Rostova signed off on multi-region AWS topology",
                "points": 10,
                "type": "positive",
                "source_event": "evt-02"
            },
            {
                "id": "c-budget",
                "label": "Budget band verified",
                "evidence": "$200K–$260K allocated in confirmed FY Q4 expansion budget",
                "points": 8,
                "type": "positive",
                "source_event": "evt-03"
            },
            {
                "id": "c-milestone",
                "label": "Defined evaluation milestones",
                "evidence": "Clear architecture review milestone achieved on schedule",
                "points": 6,
                "type": "positive",
                "source_event": "evt-02"
            },
            {
                "id": "c-security",
                "label": "Security & compliance review pending",
                "evidence": "Custom cloud infosec questionnaire (v2.4) under legal/compliance review",
                "points": -8,
                "type": "negative",
                "source_event": "evt-04"
            },
            {
                "id": "c-procur",
                "label": "Procurement review window unstarted",
                "evidence": "Standard 3-week enterprise vendor review cycle not yet initiated",
                "points": -6,
                "type": "negative",
                "source_event": "evt-05"
            },
            {
                "id": "c-pricing",
                "label": "User-tier expansion pricing objection",
                "evidence": "David Zhang queried tier discounts for seats 300-450",
                "points": -4,
                "type": "negative",
                "source_event": "evt-03"
            }
        ],

        # Timeline of deal events (Ground truth for citations)
        "timeline": [
            {
                "id": "evt-01",
                "date": "Sept 18, 2026",
                "time": "10:30 AM",
                "relative": "10d ago",
                "title": "Executive Business Review",
                "type": "EPISODE",
                "actor": "Marcus Vance (CIO)",
                "actor_role": "Executive Sponsor",
                "summary": "Marcus Vance emphasized need to consolidate 3 legacy sales tools into one unified platform before fiscal year end. Expressed strong interest in ROI metric verification.",
                "citation_tag": "Executive sponsorship",
                "badge_color": "teal"
            },
            {
                "id": "evt-02",
                "date": "Sept 21, 2026",
                "time": "2:00 PM",
                "relative": "7d ago",
                "title": "Technical Architecture Review",
                "type": "EPISODE",
                "actor": "Elena Rostova (VP Architecture)",
                "actor_role": "Technical Champion",
                "summary": "Elena validated deployment topology, SSO integration, and low-latency sync. Formally approved architectural compatibility for enterprise deployment.",
                "citation_tag": "Champion preference",
                "badge_color": "indigo"
            },
            {
                "id": "evt-03",
                "date": "Sept 24, 2026",
                "time": "11:15 AM",
                "relative": "4d ago",
                "title": "Commercial & Pricing Discussion",
                "type": "EPISODE",
                "actor": "David Zhang (Procurement)",
                "actor_role": "Commercial Lead",
                "summary": "David confirmed $200K-$260K budget allocation but pushed for a 10% concession on tier 2 enterprise licenses. Sarah held firm on multi-year terms.",
                "citation_tag": "Pricing discussion",
                "badge_color": "slate"
            },
            {
                "id": "evt-04",
                "date": "Sept 25, 2026",
                "time": "4:45 PM",
                "relative": "3d ago",
                "title": "Infosec Questionnaire Submission",
                "type": "EPISODE",
                "actor": "Cybersecurity Review Board",
                "actor_role": "Compliance Officer",
                "summary": "Submitted 84-question vendor risk assessment. 8 items regarding data residency and retention remain under review with Infosec committee.",
                "citation_tag": "Security objection",
                "badge_color": "amber"
            },
            {
                "id": "evt-05",
                "date": "Sept 27, 2026",
                "time": "9:00 AM",
                "relative": "1d ago",
                "title": "Procurement Cadence Alignment",
                "type": "EPISODE",
                "actor": "David Zhang (Procurement)",
                "actor_role": "Commercial Lead",
                "summary": "Procurement warned that contract turnaround requires a strict 21-day review buffer before November 15 fiscal closure.",
                "citation_tag": "Procurement timeline",
                "badge_color": "slate"
            }
        ],

        # Memory Inspector Components
        "memory_inspector": {
            "episodes": [
                {
                    "id": "ep-1",
                    "title": "Executive Alignment Meeting",
                    "timestamp": "Sept 18 · Zoom",
                    "key_takeaway": "CIO confirmed consolidation budget is approved for Q4.",
                    "provenance": "Transcript & CRM Note #402"
                },
                {
                    "id": "ep-2",
                    "title": "Cloud Architecture Deep-Dive",
                    "timestamp": "Sept 21 · Technical Session",
                    "key_takeaway": "Architecture team validated SSO & role isolation.",
                    "provenance": "Architecture Memo #12B"
                },
                {
                    "id": "ep-3",
                    "title": "Commercial Pricing Review",
                    "timestamp": "Sept 24 · Commercial Sync",
                    "key_takeaway": "Procurement signaled sensitivity around per-seat tier scaling.",
                    "provenance": "Pricing Model v1.2"
                },
                {
                    "id": "ep-4",
                    "title": "Compliance Questionnaire Exchange",
                    "timestamp": "Sept 25 · Email Thread",
                    "key_takeaway": "Security flagged data retention guidelines for review.",
                    "provenance": "Security Ticket #SEC-981"
                }
            ],
            "facts": [
                {
                    "id": "f-1",
                    "attribute": "Allocated Budget",
                    "value": "$240,000 ARR (Band: $200K–$260K)",
                    "confidence": "Verified (Sept 24)",
                    "provenance": "Commercial sync with David Zhang"
                },
                {
                    "id": "f-2",
                    "attribute": "Target Close Date",
                    "value": "November 15, 2026 (Fiscal Q4 Cutoff)",
                    "confidence": "Hard Deadline",
                    "provenance": "CIO Marcus Vance executive briefing"
                },
                {
                    "id": "f-3",
                    "attribute": "Primary Decision-Maker",
                    "value": "Marcus Vance (CIO)",
                    "confidence": "Verified",
                    "provenance": "Organizational mapping"
                },
                {
                    "id": "f-4",
                    "attribute": "Deployment Architecture",
                    "value": "Cloud Dedicated (AWS Multi-Region)",
                    "confidence": "Approved",
                    "provenance": "VP Architecture sign-off"
                },
                {
                    "id": "f-5",
                    "attribute": "Procurement Window",
                    "value": "21 business days mandatory legal review",
                    "confidence": "Policy Required",
                    "provenance": "Procurement guidelines"
                }
            ],
            "playbooks": [
                {
                    "id": "pb-1",
                    "code": "PLAYBOOK",
                    "name": "Enterprise Security Fast-Track",
                    "trigger": "Custom Infosec review pending > 48h",
                    "guidance": "Deliver SOC2 Type II package with pre-filled audit bridge letter directly to Compliance Lead to compress review cycle by 7 days."
                },
                {
                    "id": "pb-2",
                    "code": "PLAYBOOK",
                    "name": "Pilot-to-Procurement Conversion",
                    "trigger": "Customer requests pre-purchase technical validation",
                    "guidance": "Anchor pilot to a strict 14-day window with pre-agreed acceptance criteria. Run legal review in parallel rather than sequentially."
                },
                {
                    "id": "pb-3",
                    "code": "PLAYBOOK",
                    "name": "Commercial Tier Concession Defense",
                    "trigger": "Procurement demands 10% unit price reduction",
                    "guidance": "Protect base seat pricing by exchanging discount requests for extended 24-month commit or priority technical onboarding credits."
                }
            ]
        },

        # Call Briefs: Baseline (Without Memory) vs Memory-Grounded (With Memory)
        "briefs": {
            "without_memory": {
                "label": "Generic CRM State",
                "what_changed": "Deal stage moved to Negotiation. Total opportunity recorded at $240,000.",
                "what_matters_now": "Confirm overall pilot requirements and standard procurement timeline before scheduling next call.",
                "customer_priorities": "Standard enterprise licensing terms, pricing structure, and contract review.",
                "risks": "Deal might face standard year-end administrative delays in legal.",
                "recommended_move": "Schedule a follow-up call with the account owner to review the quote and check procurement requirements.",
                "citations": []
            },
            "with_memory": {
                "label": "Memory-Grounded Brief",
                "what_changed": "Infosec review submitted (Sept 25) with 8 items pending; procurement emphasized the strict 21-day closing window.",
                "what_matters_now": "Procurement timeline requires initiation by Oct 24 to close by Nov 15. The pending security review threatens this 21-day window.",
                "customer_priorities": "Technical validation from Elena Rostova is secured; Marcus Vance requires confirmed ROI metrics to defend the $240K allocation against competing IT line items.",
                "risks": "David Zhang is holding back legal review until security questions clear and per-seat tier pricing is clarified.",
                "recommended_move": "Lead with the structured 2-week pilot framework, then confirm procurement review requirements.",
                "citations": [
                    {"label": "Call • Sep 18 • Executive sponsorship", "event_id": "evt-01"},
                    {"label": "Meeting • Sep 21 • Champion preference", "event_id": "evt-02"},
                    {"label": "Call • Sep 24 • Pricing discussion", "event_id": "evt-03"},
                    {"label": "Review • Sep 25 • Security objection", "event_id": "evt-04"},
                    {"label": "Email • Sep 27 • Procurement timeline", "event_id": "evt-05"}
                ]
            }
        },

        # Risk & Nudge Panel (Severity, Reason, Recommended Action, Evidence)
        "risks_and_nudges": [
            {
                "id": "risk-01",
                "severity": "HIGH",
                "title": "Procurement Review Window Slippage",
                "reason": "Standard 21-day legal turnaround buffer will breach the Nov 15 fiscal year deadline if review is not initiated by Oct 24.",
                "recommended_action": "Run legal terms in parallel with the 2-week pilot rather than waiting for sequential evaluation sign-off.",
                "evidence": "Procurement Cadence Alignment (Sept 27) · Fact: 21 business days mandatory legal review"
            },
            {
                "id": "risk-02",
                "severity": "MEDIUM",
                "title": "Infosec Questionnaire Bottleneck",
                "reason": "8 questions regarding cloud data retention and audit logs remain unreviewed with the Cybersecurity Review Board.",
                "recommended_action": "Deliver pre-filled SOC2 Type II audit bridge letter directly to Compliance Lead to compress review cycle.",
                "evidence": "Infosec Questionnaire Submission (Sept 25) · Playbook: Enterprise Security Fast-Track"
            },
            {
                "id": "risk-03",
                "severity": "LOW",
                "title": "Per-Seat Volume Tier Resistance",
                "reason": "Procurement queried 10% unit pricing concession for expansion seats 300 through 450.",
                "recommended_action": "Hold seat pricing in reserve; exchange discount request for a 24-month commit or onboarding credits.",
                "evidence": "Commercial & Pricing Discussion (Sept 24) · Playbook: Commercial Tier Concession Defense"
            }
        ],

        # Newly captured live notes history for this deal
        "captured_notes": []
    },

    "strata-health": {
        "id": "strata-health",
        "account": "Strata Health Solutions",
        "name": "Platform Core Rollout",
        "stage": "Technical Validation",
        "value": "$180K",
        "value_num": 180000,
        "target_close": "Dec 05 (FY Q4)",
        "last_activity": "HIPAA BAA checklist delivered · 1d ago",
        "owner": "Marcus Bell",
        "sponsor": "Dr. Aris Thorne (Chief Medical Info Officer)",
        "champion": "Rachel Kim (VP IT Ops)",
        "procurement": "Frank Miller",
        "memory_status": "MEMORY-GROUNDED",
        "memory_state_label": "Persistent isolation active",
        "summary": "Core clinical workflow integration across 12 outpatient care facilities.",
        "base_health": 60,
        "health_contributors": [
            {"id": "c-sh-1", "label": "CMIO clinical sponsor alignment", "evidence": "Dr. Thorne confirmed EHR integration priority", "points": 10, "type": "positive", "source_event": "sh-01"},
            {"id": "c-sh-2", "label": "Technical feasibility validated", "evidence": "Sandbox API connection tested successfully", "points": 8, "type": "positive", "source_event": "sh-02"},
            {"id": "c-sh-3", "label": "HIPAA BAA legal review pending", "evidence": "Legal redlines pending on data residency", "points": -8, "type": "negative", "source_event": "sh-03"},
            {"id": "c-sh-4", "label": "Multi-site rollout schedule unconfirmed", "evidence": "Site leads request phased schedule", "points": -6, "type": "negative", "source_event": "sh-04"}
        ],
        "timeline": [
            {
                "id": "sh-01",
                "date": "Sept 15, 2026",
                "time": "11:00 AM",
                "relative": "13d ago",
                "title": "Clinical Integration Scoping",
                "type": "EPISODE",
                "actor": "Dr. Aris Thorne (CMIO)",
                "actor_role": "Executive Sponsor",
                "summary": "Outlined clinical priority to streamline outpatient charting into one interface.",
                "citation_tag": "Clinical priority",
                "badge_color": "teal"
            },
            {
                "id": "sh-02",
                "date": "Sept 23, 2026",
                "time": "3:30 PM",
                "relative": "5d ago",
                "title": "Sandbox Integration Test",
                "type": "EPISODE",
                "actor": "Rachel Kim (VP IT Ops)",
                "actor_role": "Technical Champion",
                "summary": "API sandbox testing completed with nominal latency metrics across mock patient data.",
                "citation_tag": "API test",
                "badge_color": "indigo"
            }
        ],
        "memory_inspector": {
            "episodes": [
                {"id": "sh-ep-1", "title": "Clinical Scoping Review", "timestamp": "Sept 15", "key_takeaway": "CMIO prioritizes chart consolidation.", "provenance": "EHR Sync Brief"}
            ],
            "facts": [
                {"id": "sh-f-1", "attribute": "Compliance Requirement", "value": "HIPAA BAA + SOC2 Type II", "confidence": "Mandatory", "provenance": "Strata InfoSec"}
            ],
            "playbooks": [
                {"id": "sh-pb-1", "code": "PLAYBOOK", "name": "Healthcare BAA Fast-Track", "trigger": "HIPAA BAA review pending", "guidance": "Provide standard healthcare rider with pre-signed business associate agreement."}
            ]
        },
        "briefs": {
            "without_memory": {
                "label": "Generic CRM State",
                "what_changed": "Deal in Technical Validation at $180K.",
                "what_matters_now": "Review integration timeline.",
                "customer_priorities": "Platform stability and clinical uptime.",
                "risks": "Compliance review delays.",
                "recommended_move": "Send follow-up email to check status.",
                "citations": []
            },
            "with_memory": {
                "label": "Memory-Grounded Brief",
                "what_changed": "API test succeeded; HIPAA BAA contract is with healthcare counsel.",
                "what_matters_now": "BAA turnaround is the gating factor for clinical pilot kickoff.",
                "customer_priorities": "Dr. Thorne needs assurance on clinical workflow disruption during cutover.",
                "risks": "Healthcare legal counsel averages 4 weeks unless escalated.",
                "recommended_move": "Request Rachel Kim introduce team to healthcare legal lead to execute standard BAA rider.",
                "citations": [
                    {"label": "Clinical priority", "event_id": "sh-01"},
                    {"label": "API test", "event_id": "sh-02"}
                ]
            }
        },
        "captured_notes": []
    },

    "novus-logistics": {
        "id": "novus-logistics",
        "account": "Novus Global Logistics",
        "name": "Fleet Intelligence Suite",
        "stage": "Discovery & Scoping",
        "value": "$320K",
        "value_num": 320000,
        "target_close": "Jan 20, 2027",
        "last_activity": "Initial discovery session held · 3d ago",
        "owner": "David Vance",
        "sponsor": "Theresa Ramos (Chief Operations Officer)",
        "champion": "Kenji Sato (Director Telematics)",
        "procurement": "Pending assignment",
        "memory_status": "MEMORY-GROUNDED",
        "memory_state_label": "Persistent isolation active",
        "summary": "Telemetry & AI route optimization across 1,200 heavy freight tractors in North America.",
        "base_health": 50,
        "health_contributors": [
            {"id": "c-nv-1", "label": "Executive interest in fuel reduction", "evidence": "COO identified $1.8M annual fuel waste", "points": 8, "type": "positive", "source_event": "nv-01"},
            {"id": "c-nv-2", "label": "Telematics data compatibility unconfirmed", "evidence": "Hardware gateway models vary across fleet age", "points": -6, "type": "negative", "source_event": "nv-01"}
        ],
        "timeline": [
            {
                "id": "nv-01",
                "date": "Sept 25, 2026",
                "time": "1:00 PM",
                "relative": "3d ago",
                "title": "Discovery & Telemetry Overview",
                "type": "EPISODE",
                "actor": "Theresa Ramos (COO)",
                "actor_role": "Executive Sponsor",
                "summary": "Initial exploration of real-time route optimization. Theresa emphasized 4% fuel reduction target.",
                "citation_tag": "Fuel reduction goal",
                "badge_color": "teal"
            }
        ],
        "memory_inspector": {
            "episodes": [
                {"id": "nv-ep-1", "title": "Fleet Discovery Call", "timestamp": "Sept 25", "key_takeaway": "Fleet contains 3 different onboard telematics units.", "provenance": "Ops Discovery #01"}
            ],
            "facts": [
                {"id": "nv-f-1", "attribute": "Fleet Size", "value": "1,200 power units", "confidence": "Verified", "provenance": "COO briefing"}
            ],
            "playbooks": [
                {"id": "nv-pb-1", "code": "PLAYBOOK", "name": "Telemetry Gateway Benchmarking", "trigger": "Mixed hardware vendor environments", "guidance": "Conduct sample bench test on oldest gateway variant to guarantee protocol compatibility."}
            ]
        },
        "briefs": {
            "without_memory": {
                "label": "Generic CRM State",
                "what_changed": "Discovery opened for $320K.",
                "what_matters_now": "Schedule technical presentation.",
                "customer_priorities": "Route optimization efficiency.",
                "risks": "Early stage scoping ambiguity.",
                "recommended_move": "Send slide deck to Kenji Sato.",
                "citations": []
            },
            "with_memory": {
                "label": "Memory-Grounded Brief",
                "what_changed": "Discovered 3 mixed telematics vendors across 1,200 power units.",
                "what_matters_now": "Demonstrating unified protocol parsing across all 3 hardware types without requiring sensor replacement.",
                "customer_priorities": "COO Theresa Ramos needs fuel savings proof without truck downtime.",
                "risks": "Kenji Sato may push back if proprietary cabling is required.",
                "recommended_move": "Offer a 5-vehicle bench compatibility test on their oldest gateway model to prove zero-wiring install.",
                "citations": [
                    {"label": "Fuel reduction goal", "event_id": "nv-01"}
                ]
            }
        },
        "captured_notes": []
    }
}

# Active working state store in-memory (per-session / per-deal persistence)
ACTIVE_DEALS = deepcopy(INITIAL_DEALS)


def reset_deals():
    """Resets the in-memory deal store back to pristine demo state."""
    global ACTIVE_DEALS
    ACTIVE_DEALS = deepcopy(INITIAL_DEALS)
    return ACTIVE_DEALS


def get_all_deals():
    """Returns all active deals list with current computed health scores."""
    deals_list = []
    for deal_id, deal in ACTIVE_DEALS.items():
        computed_deal = calculate_deal_health(deal)
        deals_list.append(computed_deal)
    return deals_list


def get_deal(deal_id):
    """Retrieves an isolated deal state by ID with computed health and citations."""
    deal = ACTIVE_DEALS.get(deal_id)
    if not deal:
        return None
    return calculate_deal_health(deal)


def calculate_deal_health(deal):
    """
    Computes the authoritative Health Score and positive/negative breakdowns.
    
    Formula:
    Base Health (e.g. 60) + Sum(Positive Contributors) + Sum(Negative Contributors)
    Clamped strictly between 0 and 100.
    """
    base = deal.get("base_health", 60)
    contributors = deal.get("health_contributors", [])
    
    positives = []
    negatives = []
    total_delta = 0

    for c in contributors:
        pts = c.get("points", 0)
        total_delta += pts
        if pts >= 0:
            positives.append(c)
        else:
            negatives.append(c)

    final_score = max(5, min(100, base + total_delta))

    # Health status tone
    if final_score >= 75:
        health_tone = "strong"
        health_status = "Healthy · High Momentum"
    elif final_score >= 55:
        health_tone = "moderate"
        health_status = "Moderate · Contained Friction"
    else:
        health_tone = "at_risk"
        health_status = "At Risk · Immediate Action Needed"

    deal_copy = deepcopy(deal)
    deal_copy["health_score"] = final_score
    deal_copy["health_positives"] = positives
    deal_copy["health_negatives"] = negatives
    deal_copy["health_tone"] = health_tone
    deal_copy["health_status"] = health_status
    deal_copy["base_health"] = base

    return deal_copy


def capture_deal_note(deal_id, note_text, author="Sarah Chen"):
    """
    Core interactive demonstration method:
    When a salesperson captures a new note, Memora Sales executes:
    CAPTURE -> RECALL -> REFLECT -> ACT
    
    1. Retains note in deal memory.
    2. Adds event to Timeline.
    3. Adds interaction to Episodes.
    4. Updates Facts.
    5. Updates deterministic Health Score.
    6. Generates updated With-Memory Call Brief incorporating newly captured context.
    """
    deal = ACTIVE_DEALS.get(deal_id)
    if not deal:
        return None, "Deal not found"

    clean_note = note_text.strip()
    if not clean_note:
        return None, "Note content cannot be empty"

    # 1. Real Hindsight retain() operation
    if hindsight_groq_service.is_live_configured():
        try:
            hindsight_groq_service.hindsight_retain(deal_id, clean_note, f"Logged by {author}")
        except Exception:
            pass

    now = datetime.now()
    time_str = now.strftime("%I:%M %p")
    date_str = now.strftime("%b %d, %Y")
    event_id = f"evt-live-{int(now.timestamp())}"

    # Analyze note context to extract intent and semantic significance
    lower_note = clean_note.lower()
    is_pilot = "pilot" in lower_note or "proof of concept" in lower_note or "trial" in lower_note or "2-week" in lower_note
    is_pricing = "discount" in lower_note or "price" in lower_note or "cost" in lower_note or "budget" in lower_note
    is_security = "security" in lower_note or "compliance" in lower_note or "soc2" in lower_note or "infosec" in lower_note
    is_procurement = "procurement" in lower_note or "legal" in lower_note or "contract" in lower_note

    # 1. Store in captured notes history
    note_record = {
        "id": f"note-{int(now.timestamp())}",
        "text": clean_note,
        "author": author,
        "created_at": f"{date_str} at {time_str}",
        "timestamp": now.timestamp()
    }
    deal["captured_notes"].insert(0, note_record)

    # 2. Add to Timeline as a live episode
    timeline_event = {
        "id": event_id,
        "date": date_str,
        "time": time_str,
        "relative": "Just now",
        "title": "Live Note Captured: Customer Signal" if not is_pilot else "Customer Pilot Request & Scope",
        "type": "EPISODE",
        "actor": "Elena Rostova (VP Architecture)" if is_pilot else author,
        "actor_role": "Customer Champion" if is_pilot else "Account Executive",
        "summary": clean_note,
        "citation_tag": "2-week pilot request" if is_pilot else "Recent customer note",
        "badge_color": "teal",
        "is_live": True
    }
    deal["timeline"].insert(0, timeline_event)

    # 3. Add to Memory Inspector Episodes
    episode_entry = {
        "id": f"ep-live-{int(now.timestamp())}",
        "title": "Live Customer Note: Scoping Milestone" if is_pilot else "Live Interaction Note",
        "timestamp": f"{date_str} · In-Person Sync",
        "key_takeaway": clean_note,
        "provenance": "Live Note Capture"
    }
    deal["memory_inspector"]["episodes"].insert(0, episode_entry)

    # 4. Update Facts based on deal memory
    if is_pilot:
        deal["memory_inspector"]["facts"].insert(0, {
            "id": f"fact-pilot-{int(now.timestamp())}",
            "attribute": "Evaluation Milestone",
            "value": "2-week technical pilot prior to procurement review",
            "confidence": "Customer Direct (Live)",
            "provenance": f"Note captured by {author}"
        })
        deal["memory_inspector"]["facts"].insert(1, {
            "id": f"fact-proc-dep-{int(now.timestamp())}",
            "attribute": "Procurement Dependency",
            "value": "Contingent on successful 2-week pilot milestone completion",
            "confidence": "High",
            "provenance": "Derived from latest customer request"
        })
    else:
        deal["memory_inspector"]["facts"].insert(0, {
            "id": f"fact-note-{int(now.timestamp())}",
            "attribute": "Latest Customer Signal",
            "value": clean_note[:60] + ("..." if len(clean_note) > 60 else ""),
            "confidence": "Captured Live",
            "provenance": f"Logged by {author}"
        })

    # 5. Update Health Score deterministic contributors
    # If customer proposed a concrete pilot structure, it clarifies scope and de-risks evaluation (+4)
    if is_pilot:
        # Check if contributor already exists
        has_pilot_contrib = any(c["id"] == "c-pilot-scope" for c in deal["health_contributors"])
        if not has_pilot_contrib:
            deal["health_contributors"].insert(0, {
                "id": "c-pilot-scope",
                "label": "Pilot scope clarified to de-risk procurement",
                "evidence": f"Customer agreed to structured 2-week pilot milestone ('{clean_note[:45]}...')",
                "points": 4,
                "type": "positive",
                "source_event": event_id
            })

    # 6. Update AI Call Brief (With Memory)
    # The with-memory brief visibly and substantively incorporates the newly retained memory!
    if is_pilot:
        deal["briefs"]["with_memory"]["what_changed"] = (
            f"Customer confirmed requirement for a 2-week pilot before formal procurement review. "
            f"Infosec questionnaire remains open with 8 items pending."
        )
        deal["briefs"]["with_memory"]["what_matters_now"] = (
            f"Structuring the 2-week pilot immediately is the primary gating item. "
            f"Pre-aligning pilot success criteria prevents procurement review from slipping past the Nov 15 fiscal deadline."
        )
        deal["briefs"]["with_memory"]["customer_priorities"] = (
            f"Elena Rostova and the architecture team need a low-friction 2-week pilot environment to validate SSO & export logs "
            f"before sending the commercial schedule to David Zhang."
        )
        deal["briefs"]["with_memory"]["risks"] = (
            f"If the pilot expands beyond 14 days, the 21-day procurement review window will breach the Nov 15 fiscal year cutoff."
        )
        deal["briefs"]["with_memory"]["recommended_move"] = (
            "Lead with the 2-week pilot structure, then confirm procurement review requirements."
        )
        # Update citations
        deal["briefs"]["with_memory"]["citations"].insert(0, {
            "label": "Note • Just now • 2-week pilot request",
            "event_id": event_id
        })
    else:
        deal["briefs"]["with_memory"]["what_changed"] = (
            f"New customer interaction recorded: \"{clean_note[:80]}...\". Infosec review remains in progress."
        )
        deal["briefs"]["with_memory"]["what_matters_now"] = (
            f"Incorporate the latest signal (\"{clean_note[:60]}...\") into today's conversation while maintaining the Nov 15 closing path."
        )
        deal["briefs"]["with_memory"]["recommended_move"] = (
            f"Address the recent note directly (\"{clean_note[:70]}...\"), then confirm alignment on unblocking procurement."
        )
        deal["briefs"]["with_memory"]["citations"].insert(0, {
            "label": "Recent customer note",
            "event_id": event_id
        })

    deal["last_activity"] = f"Note captured: '{clean_note[:36]}...' · Just now"

    # Real Hindsight recall() + Groq formatting for the With-Memory Call Brief
    if hindsight_groq_service.is_live_configured():
        try:
            hindsight_groq_service.generate_brief_live(deal)
        except Exception:
            pass

    # Return recalculation
    updated_deal = calculate_deal_health(deal)
    return updated_deal, None


def simulate_what_if(deal_id, strategy_key, live=True):
    """
    Executes What-If simulation for EXACTLY three fixed strategies:
    1. 'discount_10': Offer 10% discount
    2. 'pilot_first': Push for pilot first
    3. 'roi_story': Lead with ROI story
    
    Always produces:
    - LIKELY REACTION
    - RISK
    - RECOMMENDED MOVE
    - EVIDENCE
    
    100% deterministic fallback based on actual deal facts and memory state.
    """
    deal = ACTIVE_DEALS.get(deal_id)
    if not deal:
        return None

    # Check if a recent live pilot note was captured
    has_pilot_note = any("pilot" in n["text"].lower() or "trial" in n["text"].lower() for n in deal.get("captured_notes", []))
    procurement_window = "21 days"

    strategies = {
        "discount_10": {
            "strategy_id": "discount_10",
            "name": "Offer 10% discount",
            "description": "Offer an upfront 10% concession on tier 2 enterprise seat pricing to accelerate procurement sign-off.",
            "likely_reaction": (
                "Procurement Lead David Zhang will quickly accept the commercial concession, "
                "but VP Architecture Elena Rostova will view it as an attempt to bypass open technical evaluation items."
            ),
            "risk": (
                "Discounting before resolving the open infosec questionnaire weakens your negotiating posture, "
                "sacrifices $24,000 in ARR margin, and does not accelerate the mandatory 21-day legal review window."
            ),
            "recommended_move": (
                "Hold the 10% concession in reserve as a closing trade. "
                "Offer it only in exchange for an expedited 14-day procurement turnaround and multi-year commitment once technical items clear."
            ),
            "evidence": [
                {"fact": "Pricing discussion · Sept 24", "detail": "David Zhang requested tier discounts; Sarah established multi-year trade prerequisite."},
                {"fact": "Fact: Procurement Window", "detail": "21 business days mandatory legal review cannot be shortened by price cuts alone."},
                {"fact": "Playbook: Commercial Concession Defense", "detail": "Protect base seat pricing by exchanging discounts for contract length."}
            ]
        },

        "pilot_first": {
            "strategy_id": "pilot_first",
            "name": "Push for pilot first",
            "description": "Propose a bounded 2-week technical evaluation with defined acceptance criteria before contract signing.",
            "likely_reaction": (
                "High champion alignment. Elena Rostova and the architecture team will strongly endorse this path, "
                "especially following the latest request for pre-procurement validation."
                if has_pilot_note else
                "Elena Rostova will welcome hands-on validation of SSO and multi-region sync before committing 450 seats."
            ),
            "risk": (
                "If the pilot runs beyond 14 days without a pre-signed legal conversion agreement, "
                "the 21-day procurement review cycle will push final closing past the November 15 fiscal year deadline."
            ),
            "recommended_move": (
                "Grant the 2-week pilot immediately, but package it with a dual-track agreement: "
                "pre-agreed technical success criteria that automatically initiates legal/procurement review on Day 10 of the pilot."
            ),
            "evidence": [
                {"fact": "Customer Signal: Latest Pilot Request", "detail": "Customer explicitly requested a 2-week pilot before formal procurement review."} if has_pilot_note else
                {"fact": "Technical Architecture Review · Sept 21", "detail": "Elena validated deployment topology and SSO criteria."},
                {"fact": "Fact: Hard Close Date", "detail": "Nov 15 fiscal deadline requires procurement initiation no later than Oct 24."},
                {"fact": "Playbook: Pilot-to-Procurement Conversion", "detail": "Run security and procurement in parallel during 14-day validation window."}
            ]
        },

        "roi_story": {
            "strategy_id": "roi_story",
            "name": "Lead with ROI story",
            "description": "Anchor the next conversation on the $1.2M 3-year TCO consolidation savings model for CIO Marcus Vance.",
            "likely_reaction": (
                "Executive Sponsor Marcus Vance will strongly endorse the strategic business case to defend the $240K allocation against competing IT budget requests."
            ),
            "risk": (
                "David Zhang and the infosec team operate on compliance checklists, not executive ROI decks. "
                "Focusing exclusively on ROI leaves the 8 pending security questions and procurement timeline unaddressed."
            ),
            "recommended_move": (
                "Arm Marcus Vance with the 1-page executive ROI brief for his internal budget defense, "
                "while simultaneously delivering the SOC2 bridge letter to Infosec to clear the operational blocker."
            ),
            "evidence": [
                {"fact": "Executive Business Review · Sept 18", "detail": "Marcus Vance emphasized consolidating 3 legacy tools to drive operational efficiency."},
                {"fact": "Fact: Primary Decision-Maker", "detail": "Marcus Vance holds budget authority, but compliance holds veto power."},
                {"fact": "Security Questionnaire · Sept 25", "detail": "8 security questionnaire items require immediate operational response."}
            ]
        }
    }

    fallback_strat = strategies.get(strategy_key)
    if not fallback_strat:
        return None

    # Real Hindsight reflect() + Groq formatting (when live requested)
    if live and hindsight_groq_service.is_live_configured():
        try:
            res = hindsight_groq_service.run_what_if_live(deal, strategy_key, fallback_strat)
            if res:
                return res
        except Exception:
            return fallback_strat

    return fallback_strat
