"""
app.py - Main application server for Memora Sales (Copilot for Deals).

Non-negotiable stack:
- Python 3
- Flask
- Jinja2 templates
- Tailwind CSS via CDN
- Vanilla JavaScript for interactive moments

Core Thesis:
"Most agents just remember. Memora Sales learns from deal memory and turns it into the next best action."
"""

import os
import logging
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
import deal_data
import hindsight_groq_service

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("memora_sales")

app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "memora-sales-deal-memory-os-secret-2026")


def get_hindsight_status():
    """
    Returns the real-time status of the Hindsight / Groq integration.
    Shows 'Hindsight: live' when API keys are configured.
    """
    return hindsight_groq_service.get_service_status()


@app.context_processor
def inject_global_context():
    """Injects status badge and navigation state across all Jinja templates."""
    status = get_hindsight_status()
    return {
        "hindsight_status": status,
        "app_title": "Memora Sales",
        "tagline": "Most agents just remember. Memora Sales learns from deal memory and turns it into the next best action.",
        "brand_thesis": "Deal Memory OS for Enterprise Sales Teams"
    }


# ==============================================================================
# HTTP ROUTES
# ==============================================================================

@app.route("/")
def landing():
    """Landing Page: Demonstrates first 10-second proof, memory loop, and single CTA."""
    featured_deal = deal_data.get_deal("acme-expansion")
    return render_template("landing.html", deal=featured_deal)


@app.route("/dashboard")
def dashboard():
    """Dashboard: Restrained overview of active deal cards with memory status."""
    deals = deal_data.get_all_deals()
    return render_template("dashboard.html", deals=deals)


@app.route("/workspace")
def workspace_redirect():
    """Direct shortcut route to the primary demo deal workspace."""
    return redirect(url_for("deal_workspace", deal_id="acme-expansion"))


@app.route("/deal/<deal_id>")
def deal_workspace(deal_id):
    """
    Deal Workspace: The primary enterprise experience.
    Shows Deal Identity, Health Score (with formula breakdown), AI Call Brief,
    Timeline with citations, Memory Inspector, Note Capture, and What-If layer.
    """
    deal = deal_data.get_deal(deal_id)
    if not deal:
        return render_template("404.html", deal_id=deal_id), 404
    
    # Active strategy preview (default to pilot_first)
    active_strategy_key = request.args.get("strategy", "pilot_first")
    what_if_result = deal_data.simulate_what_if(deal_id, active_strategy_key)
    
    return render_template(
        "deal.html",
        deal=deal,
        what_if_result=what_if_result,
        active_strategy_key=active_strategy_key
    )


# ==============================================================================
# INTERACTION & API ENDPOINTS
# ==============================================================================

@app.route("/api/deals/<deal_id>/notes", methods=["POST"])
def api_capture_note(deal_id):
    """
    API endpoint for capturing a live deal note.
    Saves note to in-memory deal state, updates Timeline, Episodes, Facts, Health Score,
    and recalculates the With-Memory Call Brief.
    """
    data = request.get_json(silent=True) or request.form
    note_text = data.get("note", "").strip()
    author = data.get("author", "Sarah Chen")

    if not note_text:
        return jsonify({
            "success": False,
            "error": "Note text cannot be empty."
        }), 400

    updated_deal, err = deal_data.capture_deal_note(deal_id, note_text, author)
    if err:
        return jsonify({
            "success": False,
            "error": err
        }), 400

    return jsonify({
        "success": True,
        "message": "Memory retained. The next brief now uses this context.",
        "deal": updated_deal
    })


@app.route("/deal/<deal_id>/notes", methods=["POST"])
def form_capture_note(deal_id):
    """Standard form fallback for note submission if JavaScript is disabled."""
    note_text = request.form.get("note", "").strip()
    author = request.form.get("author", "Sarah Chen")

    if note_text:
        updated_deal, err = deal_data.capture_deal_note(deal_id, note_text, author)
        if err:
            flash(err, "error")
        else:
            flash("Memory retained. The next brief now uses this context.", "success")
    else:
        flash("Please enter a note to capture deal memory.", "warning")

    return redirect(url_for("deal_workspace", deal_id=deal_id))


@app.route("/api/deals/<deal_id>/what-if", methods=["POST", "GET"])
def api_what_if(deal_id):
    """
    Simulates What-If strategy with guaranteed deterministic fallback.
    Supports exactly three fixed strategies:
    1. 'discount_10'
    2. 'pilot_first'
    3. 'roi_story'
    """
    if request.method == "POST":
        data = request.get_json(silent=True) or request.form
        strategy_key = data.get("strategy", "pilot_first")
    else:
        strategy_key = request.args.get("strategy", "pilot_first")

    result = deal_data.simulate_what_if(deal_id, strategy_key)
    if not result:
        return jsonify({
            "success": False,
            "error": "Invalid strategy requested."
        }), 400

    return jsonify({
        "success": True,
        "result": result
    })


@app.route("/api/deals/reset", methods=["POST"])
def api_reset_deals():
    """Resets demo deals back to pristine initial state."""
    deal_data.reset_deals()
    return jsonify({
        "success": True,
        "message": "Demo deals state has been reset to initial baseline."
    })


@app.route("/deal/<deal_id>/reset", methods=["POST"])
def form_reset_deal(deal_id):
    """Form fallback for resetting deal demo state."""
    deal_data.reset_deals()
    flash("Deal memory reset to baseline state.", "info")
    return redirect(url_for("deal_workspace", deal_id=deal_id))


@app.route("/health")
def health():
    """Simple healthcheck endpoint."""
    return jsonify({"status": "healthy", "service": "memora-sales", "port": 3000})


# ==============================================================================
# ERROR HANDLERS (No raw stack traces or tracebacks)
# ==============================================================================

@app.errorhandler(404)
def not_found_error(error):
    return render_template("404.html", deal_id=None), 404


@app.errorhandler(500)
def internal_error(error):
    logger.error(f"Internal application error: {error}")
    return render_template(
        "deal.html",
        deal=deal_data.get_deal("acme-expansion"),
        what_if_result=deal_data.simulate_what_if("acme-expansion", "pilot_first"),
        active_strategy_key="pilot_first",
        error_notice="Memora couldn’t refresh the live memory service, so we’re showing the latest reliable deal context."
    ), 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 3000))
    logger.info(f"Starting Memora Sales Copilot on port {port}...")
    app.run(host="0.0.0.0", port=port, debug=False)
