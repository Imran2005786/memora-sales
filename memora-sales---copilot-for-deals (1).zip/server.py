"""
server.py - Zero-dependency Python HTTP Server for Memora Sales.
Built with Python 3 standard library (http.server) to guarantee instant, 100% reliable startup
without third-party package dependencies like Flask, while providing full Jinja-compatible HTML
rendering, static file serving, and JSON API endpoints.
"""

import os
import sys
import json
import mimetypes
import logging
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from datetime import datetime

import deal_data
import hindsight_groq_service

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("memora_sales")

PORT = int(os.environ.get("PORT", 3000))
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")

def escape_html(val):
    if val is None:
        return ""
    return (
        str(val)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#039;")
    )

HEAD_SHARED = """  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: {
            sans: ['"Plus Jakarta Sans"', '-apple-system', 'BlinkMacSystemFont', 'system-ui', 'sans-serif'],
            mono: ['"JetBrains Mono"', 'monospace']
          },
          colors: {
            brand: {
              50: '#f0fdfa',
              100: '#ccfbf1',
              500: '#14b8a6',
              600: '#0d9488',
              700: '#0f766e',
              800: '#115e59',
              900: '#134e4a',
            },
            slate: {
              50: '#F4F7FB',
              100: '#EEF2F7',
              200: '#D9E1EA',
              300: '#C5D0DE',
              400: '#8A97AC',
              500: '#5B667A',
              600: '#465063',
              700: '#2F384B',
              800: '#1F293D',
              900: '#172033',
            }
          }
        }
      }
    }
  </script>
  <link rel="stylesheet" href="/static/css/custom.css">
  <style>
    @keyframes pulse-highlight {
      0% { background-color: rgba(20, 184, 166, 0.25); border-color: rgba(13, 148, 136, 0.8); }
      70% { background-color: rgba(20, 184, 166, 0.15); border-color: rgba(13, 148, 136, 0.6); }
      100% { background-color: #ffffff; border-color: #D9E1EA; }
    }
    .timeline-event-highlight {
      animation: pulse-highlight 3s ease-out forwards;
      box-shadow: 0 0 0 2px rgba(13, 148, 136, 0.4);
    }
    .tabular-nums { font-variant-numeric: tabular-nums; }
  </style>"""

def render_landing_page(deal, status):
    return f"""<!DOCTYPE html>
<html lang="en" class="h-full bg-slate-50 text-slate-900 antialiased" style="background-color: #F4F7FB; color: #172033;">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Memora Sales — Your Deals Remember What Matters</title>
  <meta name="description" content="Persistent Deal Memory OS for enterprise sales teams. Captures deal interactions, preserves persistent per-deal memory, recalls context, and turns memory into the next best action.">
{HEAD_SHARED}
</head>
<body class="min-h-full flex flex-col font-sans selection:bg-teal-100 selection:text-teal-900" style="background-color: #F4F7FB; color: #172033;">
  <header class="sticky top-0 z-40 bg-white/95 backdrop-blur-xs border-b" style="border-color: #D9E1EA;">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
      <div class="flex items-center gap-6">
        <a href="/" class="flex items-center gap-2.5 group">
          <div class="w-8 h-8 rounded-lg bg-slate-900 text-teal-400 flex items-center justify-center font-bold font-mono text-base border border-slate-800 shadow-2xs group-hover:bg-slate-800 transition-colors">
            M
          </div>
          <div>
            <div class="font-bold text-slate-900 tracking-tight text-sm leading-none flex items-center gap-1.5">
              <span>Memora Sales</span>
              <span class="text-[10px] font-mono font-medium text-slate-500 uppercase px-1 py-0.2 rounded bg-slate-100 border" style="border-color: #D9E1EA;">OS</span>
            </div>
            <p class="text-[11px] text-slate-400 font-mono tracking-tight mt-0.5">Copilot for Deals</p>
          </div>
        </a>
        <nav class="hidden md:flex items-center gap-1 pl-4 border-l text-xs font-medium text-slate-600" style="border-color: #D9E1EA;">
          <a href="/dashboard" class="px-3 py-1.5 rounded-md hover:text-slate-900 hover:bg-slate-100 transition-colors">Dashboard</a>
          <a href="/deal/acme-expansion" class="px-3 py-1.5 rounded-md text-teal-700 bg-teal-50 font-semibold border border-teal-200/60">Deal Workspace (Acme)</a>
        </nav>
      </div>
      <div class="flex items-center gap-3">
        <div class="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono rounded border bg-slate-50 text-slate-700" style="border-color: #D9E1EA;" title="{escape_html(status['description'])}">
          <span class="w-1.5 h-1.5 rounded-full {'bg-emerald-500 animate-pulse' if status['is_live'] else 'bg-slate-400'}"></span>
          <span class="font-medium">{escape_html(status['label'])}</span>
        </div>
        <a href="/deal/acme-expansion" class="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 transition-colors shadow-2xs">
          <span>Open Acme Deal</span>
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
          </svg>
        </a>
      </div>
    </div>
  </header>

  <main class="flex-1">
    <div class="relative overflow-hidden bg-white">
      <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-20 lg:pt-24 lg:pb-28">
        <div class="max-w-3xl">
          <div class="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-teal-700 mb-4">
            <span class="w-1.5 h-1.5 rounded-full bg-teal-600"></span>
            <span>Deal Memory OS · Dynamics 365 · Salesforce · Teams</span>
          </div>
          <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-slate-900 leading-[1.12]">
            Your deals remember what matters.
          </h1>
          <p class="mt-6 text-lg sm:text-xl text-slate-600 leading-relaxed max-w-2xl">
            Sales systems contain static records. Memora Sales adds persistent per-deal memory on top of your workflow—capturing interactions, recalling context, and turning deal memory into the next best action.
          </p>
          <div class="mt-6 border-l-2 border-teal-600 pl-4 py-1 text-sm text-slate-700 font-medium italic">
            “Most agents just remember. Memora Sales learns from deal memory and turns it into the next best action.”
          </div>
          <div class="mt-10 flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <a href="/deal/acme-expansion" class="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 text-sm font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-all shadow-sm">
              <span>Open Deal Workspace</span>
              <svg class="w-4 h-4 text-teal-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
              </svg>
            </a>
            <a href="/dashboard" class="inline-flex items-center text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors px-3 py-2">
              View Pipeline Dashboard →
            </a>
          </div>
          <div class="mt-12 pt-8 border-t border-slate-100 grid grid-cols-3 gap-6 text-left">
            <div>
              <div class="text-2xl font-bold text-slate-900 tabular-nums">100%</div>
              <div class="text-xs text-slate-500 mt-0.5">Isolated Per-Deal Memory</div>
            </div>
            <div>
              <div class="text-2xl font-bold text-slate-900 tabular-nums">5 / 5</div>
              <div class="text-xs text-slate-500 mt-0.5">Citations Traceable to Events</div>
            </div>
            <div>
              <div class="text-2xl font-bold text-teal-700 tabular-nums">0s</div>
              <div class="text-xs text-slate-500 mt-0.5">Deterministic Fallback Latency</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </main>

  <footer class="mt-auto border-t bg-white py-6" style="border-color: #D9E1EA;">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
      <div class="flex items-center gap-2">
        <span class="font-semibold text-slate-700">Memora Sales</span>
        <span>·</span>
        <span>A persistent memory layer for enterprise sales workflows</span>
      </div>
      <div class="flex items-center gap-4 text-slate-500">
        <span>Deal memory is isolated by deal context</span>
        <span>·</span>
        <span>Deterministic fallback guarantee</span>
      </div>
    </div>
  </footer>
</body>
</html>"""

def render_dashboard_page(deals, status):
    cards_html = ""
    for d in deals:
        is_acme = d["id"] == "acme-expansion"
        border_cls = "border-teal-300 ring-1 ring-teal-100 bg-white" if is_acme else "border bg-white"
        cards_html += f"""
        <div class="border {border_cls} rounded-lg p-6 flex flex-col justify-between shadow-sm hover:shadow-md transition-shadow" style="border-color: {'#5eead4' if is_acme else '#D9E1EA'};">
          <div>
            <div class="flex items-start justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <span class="text-[11px] font-mono uppercase tracking-wider text-slate-500 font-semibold">{escape_html(d['account'])}</span>
                <h3 class="text-lg font-bold text-slate-900 tracking-tight leading-snug mt-0.5">
                  <a href="/deal/{escape_html(d['id'])}" class="hover:text-teal-700 transition-colors">{escape_html(d['name'])}</a>
                </h3>
              </div>
              <span class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-teal-50 border border-teal-200 text-teal-800 shrink-0">
                {escape_html(d['memory_status'])}
              </span>
            </div>
            <div class="py-4 space-y-2 text-xs">
              <div class="flex justify-between text-slate-600">
                <span>Stage:</span>
                <span class="font-semibold text-slate-900">{escape_html(d['stage'])}</span>
              </div>
              <div class="flex justify-between text-slate-600">
                <span>Value:</span>
                <span class="font-mono font-bold text-slate-900">{escape_html(d['value'])} ARR</span>
              </div>
              <div class="flex justify-between text-slate-600">
                <span>Health:</span>
                <span class="font-mono font-bold text-teal-700">{d['health_score']}/100</span>
              </div>
              <div class="pt-2 text-slate-500 text-[11px] leading-relaxed">
                {escape_html(d['summary'])}
              </div>
            </div>
          </div>
          <div class="pt-4 border-t border-slate-100">
            <a href="/deal/{escape_html(d['id'])}" class="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold rounded bg-slate-900 text-white hover:bg-slate-800 transition-colors">
              <span>Open Deal Workspace</span>
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
              </svg>
            </a>
          </div>
        </div>"""

    return f"""<!DOCTYPE html>
<html lang="en" class="h-full bg-slate-50 text-slate-900 antialiased" style="background-color: #F4F7FB; color: #172033;">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard — Memora Sales</title>
{HEAD_SHARED}
</head>
<body class="min-h-full flex flex-col font-sans selection:bg-teal-100 selection:text-teal-900" style="background-color: #F4F7FB; color: #172033;">
  <header class="sticky top-0 z-40 bg-white/95 backdrop-blur-xs border-b" style="border-color: #D9E1EA;">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
      <div class="flex items-center gap-6">
        <a href="/" class="flex items-center gap-2.5 group">
          <div class="w-8 h-8 rounded-lg bg-slate-900 text-teal-400 flex items-center justify-center font-bold font-mono text-base border border-slate-800 shadow-2xs group-hover:bg-slate-800 transition-colors">
            M
          </div>
          <div>
            <div class="font-bold text-slate-900 tracking-tight text-sm leading-none flex items-center gap-1.5">
              <span>Memora Sales</span>
              <span class="text-[10px] font-mono font-medium text-slate-500 uppercase px-1 py-0.2 rounded bg-slate-100 border" style="border-color: #D9E1EA;">OS</span>
            </div>
            <p class="text-[11px] text-slate-400 font-mono tracking-tight mt-0.5">Copilot for Deals</p>
          </div>
        </a>
        <nav class="hidden md:flex items-center gap-1 pl-4 border-l text-xs font-medium text-slate-600" style="border-color: #D9E1EA;">
          <a href="/dashboard" class="px-3 py-1.5 rounded-md text-slate-900 bg-slate-100 font-semibold">Dashboard</a>
          <a href="/deal/acme-expansion" class="px-3 py-1.5 rounded-md hover:text-slate-900 hover:bg-slate-100 transition-colors">Deal Workspace (Acme)</a>
        </nav>
      </div>
      <div class="flex items-center gap-3">
        <div class="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono rounded border bg-slate-50 text-slate-700" style="border-color: #D9E1EA;">
          <span class="w-1.5 h-1.5 rounded-full {'bg-emerald-500 animate-pulse' if status['is_live'] else 'bg-slate-400'}"></span>
          <span class="font-medium">{escape_html(status['label'])}</span>
        </div>
      </div>
    </div>
  </header>

  <main class="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 w-full">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b" style="border-color: #D9E1EA;">
      <div>
        <div class="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-teal-700">
          <span class="w-1.5 h-1.5 rounded-full bg-teal-600"></span>
          <span>Active Deal Memory Stores</span>
        </div>
        <h1 class="text-2xl font-bold tracking-tight text-slate-900 mt-1">Sales Pipeline & Deal Memory</h1>
        <p class="text-xs text-slate-500 mt-1">
          Persistent memory isolated per deal. Select any deal to inspect context or run next-best-action simulations.
        </p>
      </div>
      <div>
        <a href="/deal/acme-expansion" class="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 transition-colors shadow-sm">
          <span>Launch Primary Demo (Acme)</span>
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
          </svg>
        </a>
      </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
      {cards_html}
    </div>
  </main>

  <footer class="mt-auto border-t bg-white py-6" style="border-color: #D9E1EA;">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
      <div class="flex items-center gap-2">
        <span class="font-semibold text-slate-700">Memora Sales</span>
        <span>·</span>
        <span>A persistent memory layer for enterprise sales workflows</span>
      </div>
    </div>
  </footer>
</body>
</html>"""

def render_deal_workspace(deal, what_if_result, active_strategy_key, status):
    citations_html = "".join([
        f"""<button type="button" class="citation-chip inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono rounded bg-white border border-teal-200 text-teal-900 font-medium hover:bg-teal-50 shadow-2xs" data-event-id="{escape_html(c.get('event_id'))}">
             <span class="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
             <span>[{escape_html(c.get('label'))}]</span>
           </button>"""
        for c in deal["briefs"]["with_memory"]["citations"]
    ])

    timeline_html = "".join([
        f"""<div id="{escape_html(evt['id'])}" class="border rounded-lg p-4 transition-all bg-white hover:border-slate-300" style="border-color: #D9E1EA;">
             <div class="flex items-center justify-between pb-2 border-b border-slate-100 text-xs">
               <div class="flex items-center gap-2">
                 <span class="px-1.5 py-0.5 rounded font-mono text-[10px] uppercase font-bold bg-slate-100 text-slate-700">
                   {escape_html(evt['type'])}
                 </span>
                 <span class="font-bold text-slate-900">{escape_html(evt['title'])}</span>
               </div>
               <span class="text-slate-400 font-mono text-[11px]">{escape_html(evt['relative'])}</span>
             </div>
             <p class="text-xs text-slate-700 mt-2 leading-relaxed">
               {escape_html(evt['summary'])}
             </p>
             <div class="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
               <span>Actor: <strong class="text-slate-700">{escape_html(evt['actor'])}</strong> ({escape_html(evt['actor_role'])})</span>
               <span class="font-mono text-teal-800 bg-teal-50 px-2 py-0.5 rounded border border-teal-200 font-medium">
                 [{escape_html(evt['citation_tag'])}]
               </span>
             </div>
           </div>"""
        for evt in deal["timeline"]
    ])

    episodes_html = "".join([
        f"""<div class="p-3 bg-white border rounded text-xs" style="border-color: #D9E1EA;">
             <div class="flex items-center justify-between text-slate-800 font-semibold mb-1">
               <span>{escape_html(ep['title'])}</span>
               <span class="text-[10px] font-mono text-slate-400">{escape_html(ep['timestamp'])}</span>
             </div>
             <p class="text-slate-600">{escape_html(ep['key_takeaway'])}</p>
             <span class="text-[10px] text-slate-400 block mt-1">Source: {escape_html(ep['provenance'])}</span>
           </div>"""
        for ep in deal["memory_inspector"]["episodes"]
    ])

    facts_html = "".join([
        f"""<div class="p-3 bg-white flex items-start justify-between gap-4 text-xs">
             <div>
               <span class="font-bold text-slate-900 block">{escape_html(f['attribute'])}</span>
               <span class="text-slate-700">{escape_html(f['value'])}</span>
               <span class="text-[10px] text-slate-400 block mt-0.5">Source: {escape_html(f['provenance'])}</span>
             </div>
             <span class="text-[10px] font-mono px-2 py-0.5 bg-slate-100 text-slate-600 rounded shrink-0">
               {escape_html(f['confidence'])}
             </span>
           </div>"""
        for f in deal["memory_inspector"]["facts"]
    ])

    playbooks_html = "".join([
        f"""<div class="p-3 bg-white border rounded text-xs" style="border-color: #D9E1EA;">
             <div class="flex items-center justify-between text-slate-900 font-bold mb-1">
               <span>{escape_html(pb['name'])}</span>
               <span class="text-[10px] font-mono px-1.5 py-0.5 bg-teal-100 text-teal-800 rounded">{escape_html(pb['code'])}</span>
             </div>
             <div class="text-[11px] text-slate-500 font-medium mb-1">Trigger: {escape_html(pb['trigger'])}</div>
             <p class="text-slate-700 leading-relaxed">{escape_html(pb['guidance'])}</p>
           </div>"""
        for pb in deal["memory_inspector"]["playbooks"]
    ])

    evidence_html = "".join([
        f"""<li class="flex items-start gap-2 py-1 border-b last:border-b-0 text-xs" style="border-color: #EEF2F7;">
             <span class="w-1.5 h-1.5 rounded-full bg-teal-600 mt-1.5 shrink-0"></span>
             <div>
               <strong class="text-slate-900">{escape_html(ev.get('fact'))}:</strong>
               <span class="text-slate-600 ml-1">{escape_html(ev.get('detail'))}</span>
             </div>
           </li>"""
        for ev in what_if_result.get("evidence", [])
    ])

    positives_html = "".join([
        f"""<div class="flex items-start justify-between py-2 border-b border-slate-100 text-xs">
             <div class="pr-2">
               <span class="font-semibold text-slate-900">{escape_html(c['label'])}</span>
               <p class="text-[11px] text-slate-500 mt-0.5">{escape_html(c['evidence'])}</p>
             </div>
             <span class="font-mono font-bold text-teal-700 shrink-0">+{c['points']}</span>
           </div>"""
        for c in deal.get("health_positives", [])
    ])

    negatives_html = "".join([
        f"""<div class="flex items-start justify-between py-2 border-b border-slate-100 text-xs">
             <div class="pr-2">
               <span class="font-semibold text-slate-900">{escape_html(c['label'])}</span>
               <p class="text-[11px] text-slate-500 mt-0.5">{escape_html(c['evidence'])}</p>
             </div>
             <span class="font-mono font-bold text-rose-600 shrink-0">{c['points']}</span>
           </div>"""
        for c in deal.get("health_negatives", [])
    ])

    risks_html = "".join([
        f"""<div class="border rounded-lg p-4 bg-white flex flex-col justify-between {'border-rose-200 bg-rose-50/20' if r['severity'] == 'HIGH' else ('border-amber-200 bg-amber-50/20' if r['severity'] == 'MEDIUM' else '')}" style="border-color: {'#fecdd3' if r['severity'] == 'HIGH' else ('#fde68a' if r['severity'] == 'MEDIUM' else '#D9E1EA')};">
             <div>
               <div class="flex items-center justify-between pb-2 border-b {'border-rose-100' if r['severity'] == 'HIGH' else ('border-amber-100' if r['severity'] == 'MEDIUM' else 'border-slate-100')}">
                 <span class="text-[10px] font-mono font-bold px-2 py-0.5 rounded {'bg-rose-100 text-rose-800 border border-rose-200' if r['severity'] == 'HIGH' else ('bg-amber-100 text-amber-800 border border-amber-200' if r['severity'] == 'MEDIUM' else 'bg-slate-200 text-slate-700')}">
                   {r['severity']} SEVERITY
                 </span>
                 <span class="text-[10px] font-mono text-slate-400">Grounded</span>
               </div>
               <h4 class="text-xs font-bold text-slate-900 mt-3">{escape_html(r['title'])}</h4>
               <p class="text-xs text-slate-600 mt-1 leading-relaxed">{escape_html(r['reason'])}</p>
             </div>
             <div class="mt-4 pt-3 border-t border-slate-100 text-xs">
               <span class="text-[10px] font-mono uppercase text-slate-400 block">Recommended Action</span>
               <p class="text-slate-800 font-medium mt-0.5">{escape_html(r['recommended_action'])}</p>
               <span class="text-[10px] text-slate-400 block mt-1">Grounding: {escape_html(r['evidence'])}</span>
             </div>
           </div>"""
        for r in deal.get("risks_and_nudges", [])
    ])

    return f"""<!DOCTYPE html>
<html lang="en" class="h-full bg-slate-50 text-slate-900 antialiased" style="background-color: #F4F7FB; color: #172033;">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{escape_html(deal['account'])} — {escape_html(deal['name'])} | Memora Sales Workspace</title>
{HEAD_SHARED}
</head>
<body class="min-h-full flex flex-col font-sans selection:bg-teal-100 selection:text-teal-900" style="background-color: #F4F7FB; color: #172033;" data-deal-id="{escape_html(deal['id'])}">
  <header class="sticky top-0 z-40 bg-white/95 backdrop-blur-xs border-b" style="border-color: #D9E1EA;">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
      <div class="flex items-center gap-6">
        <a href="/" class="flex items-center gap-2.5 group">
          <div class="w-8 h-8 rounded-lg bg-slate-900 text-teal-400 flex items-center justify-center font-bold font-mono text-base border border-slate-800 shadow-2xs group-hover:bg-slate-800 transition-colors">
            M
          </div>
          <div>
            <div class="font-bold text-slate-900 tracking-tight text-sm leading-none flex items-center gap-1.5">
              <span>Memora Sales</span>
              <span class="text-[10px] font-mono font-medium text-slate-500 uppercase px-1 py-0.2 rounded bg-slate-100 border" style="border-color: #D9E1EA;">OS</span>
            </div>
            <p class="text-[11px] text-slate-400 font-mono tracking-tight mt-0.5">Copilot for Deals</p>
          </div>
        </a>
        <nav class="hidden md:flex items-center gap-1 pl-4 border-l text-xs font-medium text-slate-600" style="border-color: #D9E1EA;">
          <a href="/dashboard" class="px-3 py-1.5 rounded-md hover:text-slate-900 hover:bg-slate-100 transition-colors">Dashboard</a>
          <a href="/deal/acme-expansion" class="px-3 py-1.5 rounded-md text-teal-700 bg-teal-50 font-semibold border border-teal-200/60">Deal Workspace (Acme)</a>
        </nav>
      </div>
      <div class="flex items-center gap-3">
        <div class="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono rounded border bg-slate-50 text-slate-700" style="border-color: #D9E1EA;" title="{escape_html(status['description'])}">
          <span class="w-1.5 h-1.5 rounded-full {'bg-emerald-500 animate-pulse' if status['is_live'] else 'bg-slate-400'}"></span>
          <span class="font-medium">{escape_html(status['label'])}</span>
        </div>
      </div>
    </div>
  </header>

  <main class="flex-1">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" data-deal-id="{escape_html(deal['id'])}">
      
      <!-- 1. DEAL HEADER & HEALTH SCORE -->
      <div class="bg-white border rounded-xl p-6 shadow-sm mb-6" style="border-color: #D9E1EA;">
        <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div class="space-y-2">
            <div class="flex items-center gap-2.5">
              <span class="text-xs font-mono uppercase tracking-wider text-slate-500 font-semibold">{escape_html(deal['account'])}</span>
              <span class="text-slate-300">/</span>
              <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-xs font-mono font-semibold bg-teal-50 border border-teal-200 text-teal-800">
                <span class="w-1.5 h-1.5 rounded-full bg-teal-600 animate-pulse"></span>
                <span>{escape_html(deal['memory_status'])}</span>
              </span>
              <span class="text-slate-300">/</span>
              <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-xs font-mono font-medium bg-slate-100 border text-slate-700" style="border-color: #D9E1EA;">
                <span class="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                <span>{escape_html(status['label'])}</span>
              </span>
              <span class="text-slate-300">/</span>
              <span class="text-xs text-slate-400 font-mono">Owner: {escape_html(deal['owner'])}</span>
            </div>

            <h1 class="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
              {escape_html(deal['name'])}
            </h1>

            <div class="flex flex-wrap items-center gap-3 text-xs text-slate-600 pt-1">
              <span class="font-semibold text-slate-900">{escape_html(deal['stage'])}</span>
              <span class="text-slate-300">·</span>
              <span class="font-bold text-slate-900 font-mono">{escape_html(deal['value'])} ARR</span>
              <span class="text-slate-300">·</span>
              <span>Target Close: <strong class="text-slate-800">{escape_html(deal['target_close'])}</strong></span>
              <span class="text-slate-300">·</span>
              <span class="text-slate-500">Last activity: <span class="italic text-slate-700">{escape_html(deal['last_activity'])}</span></span>
            </div>
          </div>

          <!-- HEALTH SCORE AREA (Subtle Light Teal Tint) -->
          <div class="lg:w-80 border-t lg:border-t-0 lg:border-l lg:pl-6 pt-4 lg:pt-0 shrink-0 p-4 rounded-lg" style="background-color: #EFFAF8; border-color: #D9E1EA;">
            <div class="flex items-start justify-between">
              <div>
                <span class="text-[11px] font-mono uppercase tracking-wider text-teal-800 font-semibold block">Health Score</span>
                <div class="flex items-baseline gap-1 mt-0.5">
                  <span id="health-score-val" class="text-3xl font-bold text-slate-900 tabular-nums font-mono">{deal['health_score']}</span>
                  <span class="text-xs font-medium text-slate-400 font-mono">/ 100</span>
                </div>
              </div>
              <button id="why-score-btn" type="button" class="text-xs font-semibold text-teal-700 hover:text-teal-900 underline decoration-teal-400 underline-offset-2 transition-colors flex items-center gap-1">
                <span>Why this score?</span>
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
              </button>
            </div>

            <div class="w-full bg-slate-200/70 h-2 rounded-full mt-2.5 overflow-hidden">
              <div id="health-score-bar" class="h-full rounded-full {'bg-teal-600' if deal['health_score'] >= 75 else ('bg-amber-500' if deal['health_score'] >= 55 else 'bg-rose-500')} transition-all duration-500" style="width: {deal['health_score']}%"></div>
            </div>

            <div class="mt-2 flex items-center justify-between text-[11px] text-slate-500">
              <span id="health-status-label" class="font-medium text-slate-700">{escape_html(deal['health_status'])}</span>
              <span class="font-mono text-[10px] text-teal-800 font-medium">Explicit Formula</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 2. LIVE NOTE CAPTURE (Subtle Light Blue Tint) -->
      <div class="border rounded-xl p-5 shadow-xs mb-6 relative" style="background-color: #F0F7FF; border-color: #D9E1EA;">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b" style="border-color: #D9E1EA;">
          <div class="flex items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-full bg-teal-600"></span>
            <h2 class="text-sm font-bold text-slate-900 uppercase tracking-wider">Live Note Capture · Demo Interaction</h2>
          </div>
          <button id="quick-fill-pilot-note" type="button" class="text-xs font-semibold text-teal-800 hover:text-teal-950 bg-white hover:bg-teal-50 px-2.5 py-1 rounded border border-teal-300 transition-colors text-left sm:text-right shadow-2xs">
            ⚡ Insert demo signal: “Customer wants a 2-week pilot before procurement review.”
          </button>
        </div>

        <div id="note-confirmation-banner" class="hidden my-3 p-3.5 bg-teal-50 border border-teal-300 rounded-lg flex items-center gap-3 text-xs text-teal-900 font-semibold shadow-xs">
          <div class="w-5 h-5 rounded-full bg-teal-600 text-white flex items-center justify-center shrink-0">
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path>
            </svg>
          </div>
          <div>
            <span>Memory retained. The next brief now uses this context.</span>
            <p class="text-[11px] font-normal text-teal-700 mt-0.5">Timeline updated, Health Score recalculated, and With-Memory brief rewritten with verifiable citations.</p>
          </div>
        </div>

        <form id="note-capture-form" action="/deal/{escape_html(deal['id'])}/notes" method="POST" class="mt-3">
          <label for="note-input" class="sr-only">Capture customer signal</label>
          <div class="relative">
            <textarea id="note-input" name="note" rows="2" class="w-full text-sm text-slate-900 placeholder:text-slate-400 bg-white border rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-transparent transition-all shadow-2xs" style="border-color: #D9E1EA;" placeholder="Log customer interaction, requirement change, objection, or meeting outcome..."></textarea>
          </div>
          <div class="mt-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div class="text-[11px] text-slate-500">
              <span>Logs directly to Deal Memory OS · Retains isolated provenance per deal</span>
            </div>
            <button id="note-submit-btn" type="submit" class="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 transition-colors shadow-sm whitespace-nowrap">
              <span>Retain memory</span>
              <svg class="w-3.5 h-3.5 text-teal-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
              </svg>
            </button>
          </div>
        </form>
      </div>

      <!-- 3. AI CALL BRIEF (Subtle Light Lavender Tint with White Cards) -->
      <div class="border rounded-xl p-6 shadow-sm mb-8" style="background-color: #F6F2FF; border-color: #D9E1EA;">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b" style="border-color: #D9E1EA;">
          <div>
            <div class="flex items-center gap-2">
              <span class="px-2 py-0.5 text-[10px] font-mono uppercase font-bold rounded bg-teal-100 text-teal-900 border border-teal-200">
                MEMORY-GROUNDED
              </span>
              <h2 class="text-lg font-bold text-slate-900">AI Call Brief</h2>
            </div>
            <p class="text-xs text-slate-500 mt-0.5">What should I know before my next conversation?</p>
          </div>

          <div class="flex items-center bg-white/80 p-1 rounded-lg border" style="border-color: #D9E1EA;">
            <button id="btn-toggle-without-memory" type="button" class="px-3 py-1.5 text-xs font-medium rounded-md text-slate-500 hover:text-slate-900 transition-all whitespace-nowrap">
              WITHOUT MEMORY
            </button>
            <button id="btn-toggle-with-memory" type="button" class="px-3 py-1.5 text-xs font-bold rounded-md bg-white text-slate-900 shadow-sm transition-all whitespace-nowrap">
              WITH MEMORY
            </button>
          </div>
        </div>

        <div id="brief-with-memory" class="mt-5 space-y-4">
          <div>
            <span class="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-1.5">Evidence Citations (Click to inspect Timeline event)</span>
            <div id="brief-citations-list" class="flex flex-wrap gap-2">
              {citations_html}
            </div>
          </div>

          <!-- Cards primarily white (#FFFFFF) -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div class="bg-white border rounded-lg p-3.5 shadow-2xs" style="border-color: #D9E1EA;">
              <span class="text-[10px] font-mono uppercase font-bold text-slate-500 block">What Changed</span>
              <p id="brief-changed-text" class="text-xs text-slate-800 mt-1 leading-relaxed">
                {escape_html(deal['briefs']['with_memory']['what_changed'])}
              </p>
            </div>
            <div class="bg-white border rounded-lg p-3.5 shadow-2xs" style="border-color: #D9E1EA;">
              <span class="text-[10px] font-mono uppercase font-bold text-slate-500 block">What Matters Now</span>
              <p id="brief-matters-text" class="text-xs text-slate-800 mt-1 leading-relaxed">
                {escape_html(deal['briefs']['with_memory']['what_matters_now'])}
              </p>
            </div>
            <div class="bg-white border rounded-lg p-3.5 shadow-2xs" style="border-color: #D9E1EA;">
              <span class="text-[10px] font-mono uppercase font-bold text-slate-500 block">Customer Priorities</span>
              <p id="brief-priorities-text" class="text-xs text-slate-800 mt-1 leading-relaxed">
                {escape_html(deal['briefs']['with_memory']['customer_priorities'])}
              </p>
            </div>
            <div class="bg-white border rounded-lg p-3.5 shadow-2xs" style="border-color: #D9E1EA;">
              <span class="text-[10px] font-mono uppercase font-bold text-rose-700 block">Risks & Friction</span>
              <p id="brief-risks-text" class="text-xs text-slate-800 mt-1 leading-relaxed">
                {escape_html(deal['briefs']['with_memory']['risks'])}
              </p>
            </div>
          </div>

          <div class="bg-teal-50 border border-teal-300 rounded-lg p-4 mt-3">
            <div class="flex items-center gap-2 mb-1">
              <svg class="w-4 h-4 text-teal-700 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
              </svg>
              <span class="text-xs font-bold font-mono uppercase tracking-wider text-teal-900">Recommended Next Move</span>
            </div>
            <p id="brief-recommended-text" class="text-sm font-semibold text-slate-900 leading-relaxed mt-1">
              {escape_html(deal['briefs']['with_memory']['recommended_move'])}
            </p>
          </div>
        </div>

        <div id="brief-without-memory" class="hidden mt-5 space-y-4">
          <div class="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800">
            <strong>Notice:</strong> This shows what a standard CRM copilot suggests without persistent deal memory.
          </div>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="bg-white border rounded-lg p-3.5 shadow-2xs" style="border-color: #D9E1EA;">
              <span class="text-[10px] font-mono uppercase font-bold text-slate-400 block">Generic Status</span>
              <p class="text-xs text-slate-700 mt-1 leading-relaxed">
                {escape_html(deal['briefs']['without_memory']['what_changed'])}
              </p>
            </div>
            <div class="bg-white border rounded-lg p-3.5 shadow-2xs" style="border-color: #D9E1EA;">
              <span class="text-[10px] font-mono uppercase font-bold text-slate-400 block">General Focus</span>
              <p class="text-xs text-slate-700 mt-1 leading-relaxed">
                {escape_html(deal['briefs']['without_memory']['what_matters_now'])}
              </p>
            </div>
          </div>
          <div class="bg-slate-100 border rounded-lg p-4" style="border-color: #D9E1EA;">
            <span class="text-xs font-bold font-mono uppercase tracking-wider text-slate-600 block mb-1">Standard Recommendation</span>
            <p class="text-sm font-medium text-slate-800 leading-relaxed">
              {escape_html(deal['briefs']['without_memory']['recommended_move'])}
            </p>
          </div>
        </div>
      </div>

      <!-- 4. TWO-COLUMN WORKSPACE -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- LEFT COLUMN: TIMELINE & MEMORY INSPECTOR (White Cards) -->
        <div class="lg:col-span-7 space-y-6">
          <div class="bg-white border rounded-xl p-6 shadow-sm" style="border-color: #D9E1EA;">
            <div class="flex items-center justify-between pb-4 border-b mb-4" style="border-color: #D9E1EA;">
              <div>
                <h3 class="text-base font-bold text-slate-900">Deal Interaction Timeline & Grounding</h3>
                <p class="text-xs text-slate-500">Every recommendation is traceable to an event below.</p>
              </div>
              <span class="text-xs font-mono text-slate-400">Isolated Store</span>
            </div>
            <div id="timeline-events-list" class="space-y-3">
              {timeline_html}
            </div>
          </div>

          <div class="bg-white border rounded-xl p-6 shadow-sm" style="border-color: #D9E1EA;">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b mb-4" style="border-color: #D9E1EA;">
              <div>
                <h3 class="text-sm font-bold text-slate-900 uppercase tracking-wider">Memory Inspector</h3>
                <p class="text-xs text-slate-500">What Memora actually remembers about this deal</p>
              </div>
              <div class="flex items-center bg-slate-100 p-1 rounded-md border text-xs" style="border-color: #D9E1EA;">
                <button type="button" class="inspector-tab-btn px-2.5 py-1 font-semibold rounded bg-slate-900 text-white shadow-xs" data-pane="pane-episodes">
                  Episodes ({len(deal['memory_inspector']['episodes'])})
                </button>
                <button type="button" class="inspector-tab-btn px-2.5 py-1 font-medium rounded text-slate-600 hover:text-slate-900" data-pane="pane-facts">
                  Facts ({len(deal['memory_inspector']['facts'])})
                </button>
                <button type="button" class="inspector-tab-btn px-2.5 py-1 font-medium rounded text-slate-600 hover:text-slate-900" data-pane="pane-playbooks">
                  Playbooks ({len(deal['memory_inspector']['playbooks'])})
                </button>
              </div>
            </div>

            <div id="pane-episodes" class="inspector-pane space-y-2">
              <div id="episodes-list" class="space-y-2">
                {episodes_html}
              </div>
            </div>

            <div id="pane-facts" class="inspector-pane hidden space-y-2">
              <div class="divide-y divide-slate-100 border rounded-lg overflow-hidden" style="border-color: #D9E1EA;">
                {facts_html}
              </div>
            </div>

            <div id="pane-playbooks" class="inspector-pane hidden space-y-2">
              {playbooks_html}
            </div>
          </div>
        </div>

        <!-- RIGHT COLUMN: WHAT-IF REASONING ENGINE (Subtle Blue-Lavender Tint) -->
        <div class="lg:col-span-5 space-y-6">
          <div class="border rounded-xl p-6 shadow-sm sticky top-20" style="background-color: #F4F5FF; border-color: #D9E1EA;">
            <div class="pb-4 border-b" style="border-color: #D9E1EA;">
              <div class="flex items-center justify-between">
                <span class="text-[10px] font-mono uppercase font-bold text-indigo-700">Predictive Simulation Layer</span>
                <span class="text-[10px] font-mono text-slate-400">100% Deterministic Fallback</span>
              </div>
              <h3 class="text-base font-bold text-slate-900 mt-1">What-If Reasoning</h3>
              <p class="text-xs text-slate-500 mt-0.5">
                Test strategic concessions against known deal facts before the next call.
              </p>
            </div>

            <div class="mt-4 space-y-2">
              <span class="text-[10px] font-mono uppercase tracking-wider text-slate-500 block">Select Strategy:</span>
              <div class="grid grid-cols-1 gap-2">
                <button type="button" class="what-if-strategy-btn w-full text-left p-2.5 rounded-lg border text-xs font-semibold transition-all {'bg-slate-900 text-white shadow-xs active-strategy' if active_strategy_key == 'discount_10' else 'bg-white text-slate-700 hover:bg-slate-50 shadow-2xs'}" style="border-color: #D9E1EA;" data-strategy="discount_10">
                  <span class="font-mono text-[10px] block opacity-75">STRATEGY 1</span>
                  <span>Offer 10% discount</span>
                </button>
                <button type="button" class="what-if-strategy-btn w-full text-left p-2.5 rounded-lg border text-xs font-semibold transition-all {'bg-slate-900 text-white shadow-xs active-strategy' if active_strategy_key == 'pilot_first' else 'bg-white text-slate-700 hover:bg-slate-50 shadow-2xs'}" style="border-color: #D9E1EA;" data-strategy="pilot_first">
                  <span class="font-mono text-[10px] block opacity-75">STRATEGY 2</span>
                  <span>Push for pilot first</span>
                </button>
                <button type="button" class="what-if-strategy-btn w-full text-left p-2.5 rounded-lg border text-xs font-semibold transition-all {'bg-slate-900 text-white shadow-xs active-strategy' if active_strategy_key == 'roi_story' else 'bg-white text-slate-700 hover:bg-slate-50 shadow-2xs'}" style="border-color: #D9E1EA;" data-strategy="roi_story">
                  <span class="font-mono text-[10px] block opacity-75">STRATEGY 3</span>
                  <span>Lead with ROI story</span>
                </button>
              </div>

              <button id="simulate-strategy-btn" type="button" class="w-full mt-3 py-2 px-3 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors shadow-2xs flex items-center justify-center gap-1.5">
                <svg class="w-3.5 h-3.5 text-teal-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path>
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <span>Simulate strategy</span>
              </button>
            </div>

            <!-- What-If Result Card (Primarily White #FFFFFF) -->
            <div id="whatif-result-card" class="mt-5 p-4 bg-white border rounded-lg space-y-3.5 transition-opacity duration-200 shadow-2xs" style="border-color: #D9E1EA;">
              <div>
                <span class="text-[10px] font-mono uppercase font-bold text-slate-500 block">Likely Reaction</span>
                <p id="whatif-reaction" class="text-xs text-slate-800 mt-1 leading-relaxed">
                  {escape_html(what_if_result.get('likely_reaction'))}
                </p>
              </div>
              <div class="pt-2 border-t" style="border-color: #D9E1EA;">
                <span class="text-[10px] font-mono uppercase font-bold text-rose-700 block">Risk</span>
                <p id="whatif-risk" class="text-xs text-slate-800 mt-1 leading-relaxed">
                  {escape_html(what_if_result.get('risk'))}
                </p>
              </div>
              <div class="pt-2 border-t" style="border-color: #D9E1EA;">
                <span class="text-[10px] font-mono uppercase font-bold text-teal-800 block">Recommended Move</span>
                <p id="whatif-move" class="text-xs text-slate-900 font-semibold mt-1 leading-relaxed">
                  {escape_html(what_if_result.get('recommended_move'))}
                </p>
              </div>
              <div class="pt-2 border-t" style="border-color: #D9E1EA;">
                <span class="text-[10px] font-mono uppercase font-bold text-slate-500 block">Grounded Evidence</span>
                <ul id="whatif-evidence" class="mt-1.5 space-y-1">
                  {evidence_html}
                </ul>
              </div>
            </div>

            <div class="mt-6 pt-4 border-t flex items-center justify-between text-xs" style="border-color: #D9E1EA;">
              <span class="text-slate-400">Presenter controls:</span>
              <form action="/deal/{escape_html(deal['id'])}/reset" method="POST">
                <button type="submit" class="text-slate-500 hover:text-rose-600 transition-colors underline decoration-slate-300">
                  Reset demo baseline
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

      <!-- 5. RISK & NUDGE INTELLIGENCE PANEL (White Cards) -->
      <div class="mt-8 bg-white border rounded-xl p-6 shadow-sm" style="border-color: #D9E1EA;">
        <div class="flex items-center justify-between pb-4 border-b mb-5" style="border-color: #D9E1EA;">
          <div>
            <div class="flex items-center gap-2">
              <span class="w-2 h-2 rounded-full bg-rose-600"></span>
              <h3 class="text-sm font-bold uppercase tracking-wider text-slate-900">Risk & Nudge Intelligence</h3>
            </div>
            <p class="text-xs text-slate-500 mt-0.5">Automated friction detection and actionable nudges grounded in deal evidence.</p>
          </div>
          <span class="text-xs font-mono text-slate-400">Deal-Specific Detection</span>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
          {risks_html}
        </div>
      </div>
    </div>
  </main>

  <!-- "Why this score?" Modal -->
  <div id="why-score-modal" class="hidden fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-2xs flex items-center justify-center p-4">
    <div class="bg-white rounded-xl max-w-lg w-full border shadow-xl overflow-hidden" style="border-color: #D9E1EA;">
      <div class="p-5 border-b flex items-center justify-between" style="border-color: #D9E1EA;">
        <div>
          <span class="text-[10px] font-mono uppercase tracking-wider text-teal-700 font-bold">Explicit Deterministic Formula</span>
          <h3 class="text-base font-bold text-slate-900 mt-0.5">Why this Health Score: {deal['health_score']} / 100</h3>
        </div>
        <button id="why-score-close" type="button" class="text-slate-400 hover:text-slate-600 p-1">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
          </svg>
        </button>
      </div>
      <div class="p-5 space-y-4 text-xs max-h-[70vh] overflow-y-auto">
        <div class="p-3 bg-slate-50 border rounded-lg text-slate-700" style="border-color: #D9E1EA;">
          <span class="font-mono font-bold block mb-1">Formula:</span>
          <code>Health = Base Score ({deal['base_health']}) + Σ(Positive Evidence) - Σ(Risk Evidence)</code>
          <p class="text-[11px] text-slate-500 mt-1">Every point is tied to verified customer actions. No black-box guesses.</p>
        </div>
        <div>
          <span class="font-bold text-teal-900 uppercase font-mono text-[10px] tracking-wider block mb-2">Positive Contributors</span>
          <div id="why-score-contributors-list" class="space-y-2">
            {positives_html}
          </div>
        </div>
        <div class="pt-2 border-t" style="border-color: #D9E1EA;">
          <span class="font-bold text-rose-900 uppercase font-mono text-[10px] tracking-wider block mb-2">Risk / Friction Deductions</span>
          <div class="space-y-2">
            {negatives_html}
          </div>
        </div>
        <div class="pt-3 border-t-2 flex items-center justify-between font-bold text-sm" style="border-color: #D9E1EA;">
          <span>Authoritative Total</span>
          <span class="font-mono text-teal-800">{deal['health_score']} / 100</span>
        </div>
      </div>
      <div class="p-4 bg-slate-50 border-t text-right" style="border-color: #D9E1EA;">
        <button onclick="document.getElementById('why-score-modal').classList.add('hidden')" class="px-4 py-2 bg-slate-900 text-white rounded text-xs font-semibold hover:bg-slate-800">
          Close Inspector
        </button>
      </div>
    </div>
  </div>

  <footer class="mt-auto border-t bg-white py-6" style="border-color: #D9E1EA;">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
      <div class="flex items-center gap-2">
        <span class="font-semibold text-slate-700">Memora Sales</span>
        <span>·</span>
        <span>A persistent memory layer for enterprise sales workflows</span>
      </div>
    </div>
  </footer>

  <script src="/static/js/deal.js"></script>
</body>
</html>"""

class MemoraServer(BaseHTTPRequestHandler):
    def send_json(self, data, status=200):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_html(self, html_str, status=200):
        body = html_str.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_redirect(self, location):
        self.send_response(302)
        self.send_header("Location", location)
        self.end_headers()

    def serve_static(self, path):
        # Prevent directory traversal
        clean_path = os.path.normpath(path).lstrip("/")
        file_path = os.path.join(STATIC_DIR, clean_path[len("static/"):])
        if os.path.isfile(file_path):
            mime_type, _ = mimetypes.guess_type(file_path)
            with open(file_path, "rb") as f:
                content = f.read()
            self.send_response(200)
            self.send_header("Content-Type", mime_type or "application/octet-stream")
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
            return True
        return False

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        if path == "/health":
            self.send_json({"status": "healthy", "service": "memora-sales", "port": PORT})
            return

        if path.startswith("/static/"):
            if self.serve_static(path):
                return
            self.send_response(404)
            self.end_headers()
            return

        status = hindsight_groq_service.get_service_status()

        if path in ("/", ""):
            deal = deal_data.get_deal("acme-expansion")
            self.send_html(render_landing_page(deal, status))
            return

        if path == "/dashboard":
            deals = deal_data.get_all_deals()
            self.send_html(render_dashboard_page(deals, status))
            return

        if path == "/workspace":
            self.send_redirect("/deal/acme-expansion")
            return

        if path.startswith("/deal/"):
            parts = [p for p in path.split("/") if p]
            if len(parts) >= 2:
                deal_id = parts[1]
                deal = deal_data.get_deal(deal_id)
                if not deal:
                    self.send_html("<h1>404 - Deal not found</h1>", status=404)
                    return
                strat = query.get("strategy", ["pilot_first"])[0]
                what_if_res = deal_data.simulate_what_if(deal_id, strat, live=False)
                self.send_html(render_deal_workspace(deal, what_if_res, strat, status))
                return

        if path.startswith("/api/deals/"):
            parts = [p for p in path.split("/") if p]
            if len(parts) >= 3:
                deal_id = parts[2]
                deal = deal_data.get_deal(deal_id)
                if deal:
                    self.send_json({"deal": deal, "status": status})
                else:
                    self.send_json({"error": "Deal not found"}, 404)
                return

        self.send_html("<h1>404 - Not Found</h1>", status=404)

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        content_len = int(self.headers.get("Content-Length", 0))
        post_body = self.rfile.read(content_len).decode("utf-8") if content_len > 0 else ""
        content_type = self.headers.get("Content-Type", "")

        data = {}
        if post_body:
            try:
                data = json.loads(post_body)
            except Exception:
                try:
                    parsed_form = parse_qs(post_body)
                    data = {k: v[0] for k, v in parsed_form.items()}
                except Exception:
                    data = {}

        if path == "/api/deals/reset":
            deal_data.reset_deals()
            self.send_json({"success": True, "message": "Demo deals state has been reset to initial baseline."})
            return

        if path.endswith("/reset"):
            deal_data.reset_deals()
            parts = [p for p in path.split("/") if p]
            deal_id = parts[1] if len(parts) > 1 else "acme-expansion"
            self.send_redirect(f"/deal/{deal_id}")
            return

        if "/notes" in path:
            parts = [p for p in path.split("/") if p]
            deal_id = parts[2] if parts[0] == "api" else parts[1]
            note_text = data.get("note", "").strip()
            author = data.get("author", "Sarah Chen")
            updated_deal, err = deal_data.capture_deal_note(deal_id, note_text, author)
            if parts[0] == "api":
                if err:
                    self.send_json({"success": False, "error": err}, 400)
                else:
                    self.send_json({"success": True, "deal": updated_deal, "message": "Memory retained. The next brief now uses this context."})
            else:
                self.send_redirect(f"/deal/{deal_id}")
            return

        if "/what-if" in path:
            parts = [p for p in path.split("/") if p]
            deal_id = parts[2] if parts[0] == "api" else parts[1]
            strat = data.get("strategy", "pilot_first")
            result = deal_data.simulate_what_if(deal_id, strat, live=True)
            self.send_json({"success": True, "result": result})
            return

        self.send_json({"error": "Endpoint not found"}, 404)

class ReusableServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True

if __name__ == "__main__":
    server = ReusableServer(("0.0.0.0", PORT), MemoraServer)
    logger.info(f"Serving Memora Sales Copilot on port {PORT} with zero dependencies...")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
