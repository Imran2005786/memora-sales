"""
hindsight_groq_service.py - Real Hindsight Memory & Groq LLM Integration Service

Integrates:
- Hindsight API (https://api.hindsight.vectorize.io):
  - retain(): POST /v1/default/banks/{bank_id}/memories
  - recall(): POST /v1/default/banks/{bank_id}/memories/recall
  - reflect(): POST /v1/default/banks/{bank_id}/reflect
- Groq API (https://api.groq.com/openai/v1/chat/completions):
  - High-speed formatting and synthesis (models: qwen/qwen3.8-27b, openai/gpt-oss-120b)

Graceful Fallback:
If API keys are missing, network calls fail, or timeouts occur,
the service smoothly falls back to deterministic deal logic without crashing.
"""

import os
import time
import re
import json
import logging
import urllib.request
import urllib.error

logger = logging.getLogger("memora_sales.ai")

HINDSIGHT_BASE_URL = os.environ.get("HINDSIGHT_BASE_URL", "https://api.hindsight.vectorize.io")
GROQ_BASE_URL = "https://api.groq.com/openai/v1"
# Ordered by speed, quota efficiency, and reasoning capability
GROQ_MODELS = ["openai/gpt-oss-20b", "qwen/qwen3.8-27b", "openai/gpt-oss-120b"]


def get_hindsight_api_key():
    return os.environ.get("HINDSIGHT_API_KEY", "").strip()


def get_groq_api_key():
    return os.environ.get("GROQ_API_KEY", "").strip()


def is_live_configured():
    """Returns True if both Hindsight and Groq keys are present in the environment."""
    return bool(get_hindsight_api_key() and get_groq_api_key())


def get_service_status():
    """
    Returns the real-time status of the Hindsight / Groq integration.
    Requirement: Show 'Hindsight: live' when keys are present.
    """
    if is_live_configured():
        return {
            "code": "live",
            "label": "Hindsight: live",
            "description": "Hindsight persistent memory & Groq LLM reasoning live",
            "is_live": True,
            "tone": "emerald"
        }
    return {
        "code": "not_configured",
        "label": "Hindsight: not configured",
        "description": "Running on deterministic Deal Memory engine",
        "is_live": False,
        "tone": "slate"
    }


def ensure_bank(deal_id, name=None):
    """Ensures a memory bank exists in Hindsight for the specified deal."""
    key = get_hindsight_api_key()
    if not key:
        return False

    url = f"{HINDSIGHT_BASE_URL}/v1/default/banks/{deal_id}"
    payload = {
        "name": name or f"Deal Memory: {deal_id}",
        "mission": f"Reason over {deal_id} accumulated customer, stakeholder, timeline, and commercial context."
    }
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "User-Agent": "MemoraSales/1.0"
        },
        method="PUT"
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as res:
            return res.status in (200, 201)
    except Exception as e:
        logger.info(f"Hindsight ensure_bank notice for {deal_id}: {e}")
        return False


def hindsight_retain(deal_id, note_text, context="live_note"):
    """
    Core Hindsight retain() operation:
    Stores the memory in the deal's Hindsight memory bank.
    Uses async: True for instantaneous background extraction.
    Includes adaptive retry and generous timeout to prevent transient network read timeouts.
    """
    key = get_hindsight_api_key()
    if not key:
        return False, "Hindsight key not configured"

    url = f"{HINDSIGHT_BASE_URL}/v1/default/banks/{deal_id}/memories"
    payload = {
        "async": True,
        "items": [
            {
                "content": note_text,
                "context": context,
                "document_id": deal_id
            }
        ]
    }
    encoded_payload = json.dumps(payload).encode("utf-8")

    # Try up to 2 attempts with a resilient 15s timeout
    for attempt in range(2):
        req = urllib.request.Request(
            url,
            data=encoded_payload,
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
                "User-Agent": "MemoraSales/1.0"
            },
            method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=15) as res:
                if res.status in (200, 201, 202):
                    logger.info(f"Hindsight retain() succeeded for {deal_id} (attempt {attempt + 1})")
                    return True, None
                return False, f"HTTP {res.status}"
        except urllib.error.HTTPError as e:
            logger.info(f"Hindsight retain() returned HTTP {e.code}: {e.reason}, local memory maintained")
            return False, f"HTTP {e.code}"
        except Exception as e:
            if attempt == 0:
                logger.info(f"Hindsight retain() attempt 1 transient timeout: {e}; retrying...")
                continue
            logger.info(f"Hindsight retain() network call timed out after retry; deterministic local deal memory securely active: {e}")
            return False, str(e)

    return False, "Retain attempt limit reached"


def hindsight_recall(deal_id, query="deal priorities, objections, and timeline"):
    """
    Core Hindsight recall() operation:
    Semantically retrieves relevant memories and facts from the deal's bank.
    """
    key = get_hindsight_api_key()
    if not key:
        return []

    url = f"{HINDSIGHT_BASE_URL}/v1/default/banks/{deal_id}/memories/recall"
    payload = {"query": query}
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "User-Agent": "MemoraSales/1.0"
        },
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=12) as res:
            data = json.loads(res.read().decode("utf-8"))
            results = data.get("results", [])
            extracted = [r.get("text", "") for r in results if r.get("text")]
            logger.info(f"Hindsight recall() returned {len(extracted)} memories for {deal_id}")
            return extracted
    except urllib.error.HTTPError as e:
        logger.info(f"Hindsight recall() returned HTTP {e.code}: {e.reason}, local memory maintained")
        return []
    except Exception as e:
        logger.info(f"Hindsight recall() network call timed out, smoothly maintaining local deal context: {e}")
        return []


def hindsight_reflect(deal_id, query):
    """
    Core Hindsight reflect() operation:
    Executes agentic reasoning over the deal's accumulated memories.
    """
    key = get_hindsight_api_key()
    if not key:
        return None

    url = f"{HINDSIGHT_BASE_URL}/v1/default/banks/{deal_id}/reflect"
    payload = {"query": query, "budget": "low"}
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "User-Agent": "MemoraSales/1.0"
        },
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as res:
            data = json.loads(res.read().decode("utf-8"))
            answer = data.get("text") or data.get("answer") or ""
            logger.info(f"Hindsight reflect() succeeded for {deal_id} (length: {len(answer)})")
            return answer
    except urllib.error.HTTPError as e:
        logger.info(f"Hindsight reflect() returned HTTP {e.code}: {e.reason}, local reasoning maintained")
        return None
    except Exception as e:
        logger.info(f"Hindsight reflect() network call timed out, smoothly maintaining local deal reasoning: {e}")
        return None


def parse_groq_json(raw_text):
    """
    Robust JSON parser for LLM responses.
    Handles:
    - Markdown code fences (```json ... ```)
    - Extraneous leading/trailing text outside JSON
    - Truncated strings / unterminated quotes
    - Missing closing brackets and braces
    - Fallback regex extraction for brief and what-if schema keys
    """
    if not raw_text or not isinstance(raw_text, str):
        return None

    clean = raw_text.strip()
    if clean.startswith("```json"):
        clean = clean[7:]
    elif clean.startswith("```"):
        clean = clean[3:]
    if clean.endswith("```"):
        clean = clean[:-3]
    clean = clean.strip()

    # 1. Direct standard parse
    try:
        parsed = json.loads(clean)
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        pass

    # 2. Extract outermost JSON structure between first { and last }
    first_brace = clean.find("{")
    last_brace = clean.rfind("}")
    if first_brace != -1 and last_brace > first_brace:
        candidate = clean[first_brace : last_brace + 1]
        try:
            parsed = json.loads(candidate)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass

    # 3. Auto-repair truncated output (e.g. unterminated strings or missing closing brackets)
    if first_brace != -1:
        snippet = clean[first_brace:]
        in_quote = False
        escaped = False
        for ch in snippet:
            if ch == "\\" and not escaped:
                escaped = True
                continue
            if ch == '"' and not escaped:
                in_quote = not in_quote
            escaped = False
        if in_quote:
            snippet += '"'

        # Balance square brackets and curly braces
        open_sq = snippet.count("[") - snippet.count("]")
        open_cu = snippet.count("{") - snippet.count("}")
        snippet += ("]" * max(0, open_sq)) + ("}" * max(0, open_cu))
        try:
            parsed = json.loads(snippet)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass

    # 4. Regex extraction fallback to salvage valid structured fields from truncated text
    extracted = {}

    # What-If fields
    for key in ["likely_reaction", "risk", "recommended_move"]:
        m = re.search(rf'"{key}"\s*:\s*"((?:[^"\\]|\\.)*)"', clean, re.DOTALL)
        if m:
            extracted[key] = m.group(1).replace('\\"', '"').replace("\\n", "\n").strip()

    ev_matches = re.findall(
        r'\{\s*"fact"\s*:\s*"((?:[^"\\]|\\.)*)"\s*,\s*"detail"\s*:\s*"((?:[^"\\]|\\.)*)"\s*\}',
        clean,
        re.DOTALL
    )
    if ev_matches:
        extracted["evidence"] = [
            {"fact": f.replace('\\"', '"').strip(), "detail": d.replace('\\"', '"').strip()}
            for f, d in ev_matches
        ]

    # Brief fields
    for key in ["what_changed", "what_matters_now", "customer_priorities", "risks"]:
        m = re.search(rf'"{key}"\s*:\s*"((?:[^"\\]|\\.)*)"', clean, re.DOTALL)
        if m:
            extracted[key] = m.group(1).replace('\\"', '"').replace("\\n", "\n").strip()

    if len(extracted) >= 2:
        return extracted

    return None


def groq_completion(prompt, max_tokens=1200):
    """
    Calls Groq API to format or synthesize responses at high speed.
    Features:
    - Multi-model failover pool (gpt-oss-20b -> qwen3.8-27b -> gpt-oss-120b)
    - Rate limit (HTTP 429) detection with backoff & seamless fallback
    - Generous max_tokens default to prevent mid-string truncation
    """
    key = get_groq_api_key()
    if not key:
        return None

    for idx, model in enumerate(GROQ_MODELS):
        url = f"{GROQ_BASE_URL}/chat/completions"
        payload = {
            "model": model,
            "messages": [
                {
                    "role": "system",
                    "content": "You are the AI engine for Memora Sales (Copilot for Deals). Always return clean, precise, professional output in valid compact JSON."
                },
                {"role": "user", "content": prompt}
            ],
            "max_tokens": max_tokens
        }
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
                "User-Agent": "MemoraSales/1.0"
            }
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as res:
                data = json.loads(res.read().decode("utf-8"))
                content = data["choices"][0]["message"].get("content", "").strip()
                if content:
                    if idx > 0:
                        logger.info(f"Groq completion succeeded using fallback model: {model}")
                    return content
        except urllib.error.HTTPError as e:
            if e.code == 429:
                retry_header = e.headers.get("retry-after") or e.headers.get("x-ratelimit-reset-tokens") or ""
                logger.info(f"Groq model {model} rate limited (HTTP 429); switching to next model in pool. Info: {retry_header}")
                if idx == 0:
                    time.sleep(0.5)
                continue
            else:
                logger.info(f"Groq completion with model {model} returned HTTP {e.code}: {e.reason}, trying next model")
                continue
        except Exception as e:
            logger.info(f"Groq completion with model {model} error: {e}, trying next model")
            continue

    return None


def generate_brief_live(deal):
    """
    Replaces mock generate_brief() with real Hindsight recall() + Groq formatting:
    1. Calls Hindsight recall() to retrieve relevant memories.
    2. Uses Groq to synthesize the 5 structured brief dimensions.
    3. Guarantees citation grounding and fallback reliability.
    """
    deal_id = deal.get("id", "acme-expansion")
    
    # 1. Hindsight recall
    recalled_items = hindsight_recall(deal_id, "pilot requirements, procurement review, security review, and close date")
    
    # Check if a recent live pilot note was captured in deal state
    has_pilot_note = any("pilot" in n.get("text", "").lower() or "2-week" in n.get("text", "").lower() for n in deal.get("captured_notes", []))
    recalled_context_str = "\n".join([f"- {item}" for item in recalled_items[:6]]) if recalled_items else "Standard deal milestones in progress."

    # 2. Groq formatting
    prompt = f"""
Given this B2B enterprise deal context:
Account: {deal.get('account')}
Deal: {deal.get('name')} (${deal.get('value')} ARR)
Target Close: {deal.get('target_close')}
Has recent pilot request: {has_pilot_note}

Hindsight Recalled Memories:
{recalled_context_str}

Format a concise, evidence-grounded AI Call Brief with these 5 fields in JSON format:
{{
  "what_changed": "1-2 sentences summarizing the latest customer signal or security progress",
  "what_matters_now": "1-2 sentences identifying the primary gating timeline or review bottleneck",
  "customer_priorities": "1-2 sentences identifying champion/sponsor priorities",
  "risks": "1-2 sentences identifying legal or schedule friction",
  "recommended_move": "Direct tactical recommendation"
}}

IMPORTANT REQUIREMENTS:
- If a pilot request is present, the 'recommended_move' MUST state: "Lead with the 2-week pilot structure, then confirm procurement review requirements."
- Keep sentences concise, punchy, and grounded in facts.
- Return ONLY the JSON object. No markdown preamble.
"""
    groq_output = groq_completion(prompt, max_tokens=1200)

    if groq_output:
        parsed = parse_groq_json(groq_output)
        if parsed and ("what_changed" in parsed or "recommended_move" in parsed):
            # Merge into deal's with_memory brief
            brief = deal["briefs"]["with_memory"]
            brief["what_changed"] = parsed.get("what_changed", brief["what_changed"])
            brief["what_matters_now"] = parsed.get("what_matters_now", brief["what_matters_now"])
            brief["customer_priorities"] = parsed.get("customer_priorities", brief["customer_priorities"])
            brief["risks"] = parsed.get("risks", brief["risks"])
            
            if has_pilot_note:
                brief["recommended_move"] = "Lead with the 2-week pilot structure, then confirm procurement review requirements."
            else:
                brief["recommended_move"] = parsed.get("recommended_move", brief["recommended_move"])
            
            logger.info("Successfully generated brief using real Hindsight + Groq")
            return brief

    # Fallback: Return current deal deterministic brief
    return deal["briefs"]["with_memory"]


def run_what_if_live(deal, strategy_key, fallback_result):
    """
    Replaces mock run_what_if() with real Hindsight reflect() + Groq formatting:
    1. Calls Hindsight reflect() with the strategic scenario.
    2. Uses Groq to format the reflection into the 4 structured dimensions:
       - likely_reaction
       - risk
       - recommended_move
       - evidence
    3. Falls back smoothly if reflection or formatting fails.
    """
    deal_id = deal.get("id", "acme-expansion")
    strategy_name = fallback_result.get("name", strategy_key)
    strategy_desc = fallback_result.get("description", "")

    # 1. Hindsight reflect
    query = (
        f"Evaluate the sales strategy '{strategy_name}' ({strategy_desc}) for deal {deal_id}. "
        f"Consider Elena Rostova (Architecture), David Zhang (Procurement), Marcus Vance (CIO), and the Nov 15 close date."
    )
    reflect_text = hindsight_reflect(deal_id, query)

    # 2. Groq formatting
    prompt = f"""
You are the negotiation simulation engine for Memora Sales.
Deal: {deal.get('account')} - {deal.get('name')}
Strategy Tested: {strategy_name} ({strategy_desc})

Hindsight Reflection Reasoning:
{reflect_text or 'Standard commercial trade evaluation.'}

Format this evaluation into exactly 4 structured dimensions in JSON format:
{{
  "likely_reaction": "1-2 sentences on how stakeholders will react",
  "risk": "1-2 sentences on downside or schedule risks",
  "recommended_move": "1-2 sentences on the recommended tactical action",
  "evidence": [
    {{"fact": "Short fact or event title", "detail": "Specific deal grounding detail"}},
    {{"fact": "Short fact or event title", "detail": "Specific deal grounding detail"}},
    {{"fact": "Short fact or event title", "detail": "Specific deal grounding detail"}}
  ]
}}

Requirements:
- Ensure the evidence references specific deal context (e.g. Sept 24 pricing sync, 21-day legal turnaround, Nov 15 close date).
- Keep descriptions clear, concise, and professional (1-2 sentences per field).
- Return ONLY the JSON object.
"""
    groq_output = groq_completion(prompt, max_tokens=1500)

    if groq_output:
        parsed = parse_groq_json(groq_output)
        if parsed and ("likely_reaction" in parsed or "risk" in parsed or "recommended_move" in parsed):
            evidence = parsed.get("evidence")
            if not isinstance(evidence, list) or len(evidence) == 0:
                evidence = fallback_result["evidence"]
            res = {
                "strategy_id": strategy_key,
                "name": strategy_name,
                "description": strategy_desc,
                "likely_reaction": parsed.get("likely_reaction", fallback_result["likely_reaction"]),
                "risk": parsed.get("risk", fallback_result["risk"]),
                "recommended_move": parsed.get("recommended_move", fallback_result["recommended_move"]),
                "evidence": evidence
            }
            logger.info(f"Successfully generated What-If '{strategy_key}' using Hindsight reflect() + Groq")
            return res

    # Fallback to deterministic result
    return fallback_result
